#!/bin/sh

## find the min/max from a column of numbers
find_min()
{
   awk '{if(min==""){min=$1}; if($1!="" && $1<min) {min=$1};} END {print min}'
}
find_max()
{
   awk '{if(max==""){max=$1}; if($1!="" && $1>max) {max=$1};} END {print max}'
}

## Check the PBS queue status
funcQueStat(){
  i=0
  j=0
  echo -n var aQueStat=[
  for queName in $queList;
  do
          let i=$i+1
          queNodes=`grep $queName $QUEDIAGN|wc -l`
          queBusyNodes=`grep $queName $QUEDIAGN|grep -v Drained|awk '{print $3}'|grep ^0:|wc -l`
          queFreeNodes=`grep $queName $QUEDIAGN|grep Idle|wc -l`
          queFreeCore=`tail -n2 $QUEDIAGT|head -n1 |awk -F$queName '{print $2}'|awk -F':' '{print $1}'`
          queMaxPPN=`grep $queName $QUEDIAGN|awk '{print $3}' |awk -F':' '{print $2}' |find_max`
          queMaxMem=`grep $queName $QUEDIAGN|awk '{print $4}' |awk -F':' '{print $2}' |find_max`

          queChargeRate=`grep $queName $QUERATE |awk '{print $4}'`
          if [ -z $queChargeRate ];then
                queChargeRate='1.0'
          fi

          /opt/gridview/pbs/dispatcher/bin/qstat -Qf1 $queName > $QTMPDIR/$queName.conf 2>&1

          queMaxNodect=`grep 'resources_max.nodect' $QTMPDIR/$queName.conf | awk '{print $3}'`
          if [ -z "$queMaxNodect" ]; then
            queMaxNodect=unlimit
          fi
          queMinNodect=`grep 'resources_min.nodect' $QTMPDIR/$queName.conf | awk '{print $3}'`
          if [ -z "$queMinNodect" ]; then
            queMinNodect=unlimit
          fi
          queMaxNcpus=`grep 'resources_max.ncpus'  $QTMPDIR/$queName.conf | awk '{print $3}'`
          if [ -z "$queMaxNcpus" ]; then
            queMaxNcpus=unlimit
          fi
          queMinNcpus=`grep 'resources_min.ncpus'  $QTMPDIR/$queName.conf | awk '{print $3}'`
          if [ -z "$queMinNcpus" ]; then
            queMinNcpus=unlimit
          fi
          queMaxWalltime=`grep 'resources_max.walltime' $QTMPDIR/$queName.conf | awk '{print $3}'`
          if [ -z "$queMaxWalltime" ]; then
            queMaxWalltime=unlimit
          fi
          queMinWalltime=`grep 'resources_min.walltime' $QTMPDIR/$queName.conf | awk '{print $3}'`
          if [ -z "$queMinWalltime" ]; then
            queMinWalltime=unlimit
          fi

          if [ -z "`grep "acl_user_enable = True" $QTMPDIR/$queName.conf`" ];then
            queAcceIs=true
#            if [ $i -gt 1 ];then 
#            	queAcceList="$queAcceList," 
#            fi
#            queAcceList=$queAcceList[\"$queName\"]
          else
            if [ -z "`grep "acl_users" $QTMPDIR/$queName.conf |grep $CHECKUSER`" ]; then
                queAcceIs=false
            else
                queAcceIs=true
#                if [ $i -gt 1 ];then 
#                	queAcceList="$queAcceList," 
#                fi
#                queAcceList=$queAcceList[\"$queName\"]
            fi
          fi

          if [ "$queAcceIs" == true ];then
                if [ $j -gt 0 ];then
                        queAcceList="$queAcceList,[\"$queName\"]"
                else
                        queAcceList="$queAcceList[\"$queName\"]"
                        let j=$j+1
                fi
          fi

          if [ $i -gt 1 ];then
            echo -n ,
          fi
          echo -n [$i,\'$queName\',\'$queNodes\',\'$queBusyNodes\',\'$queFreeNodes\',\'$queFreeCore\',\'$queChargeRate\',\'$queAcceIs\',\'$queMaxPPN\',\'$queMaxMem\',\'$queMaxNodect\',\'$queMaxNcpus\',\'$queMaxWalltime\',\'$queMinNodect\',\'$queMinNcpus\',\'$queMinWalltime\']
  done
  echo ]\;
}

## main ##
source /etc/profile.d/dawning.sh

export QTIMESTAMP=`date +%g%m%d_%H%M`
export DOLLAR=$

## define the temp files
QTMPDIR=/tmp/que$CHECKUSER$QTIMESTAMP
mkdir -p $QTMPDIR
chmod 777 $QTMPDIR
QUEDIAGN=$QTMPDIR/queueDiagN$QTIMESTAMP
QUEDIAGT=$QTMPDIR/queueDiagT$QTIMESTAMP
QUERATE=$QTMPDIR/queueRate$QTIMESTAMP

/opt/gridview/pbs/dispatcher-sched/bin/diagnose -n -v > $QUEDIAGN 2>&1
/opt/gridview/pbs/dispatcher-sched/bin/diagnose -t > $QUEDIAGT 2>&1

## print the ClusQuota info
get_clusquota_info()
{
    touch $QUERATE
    ## clusqota process does not start
    if [ $(ps aux|grep '\<clusquota\>'|wc -l) -lt 2 ];then
        clusquota_available=0;
        echo "var clusquota_available=0;"
        return;
    fi
    # maui does not use clusquota
    if [ $(/opt/gridview/pbs/dispatcher-sched/bin/showconfig|grep '\<GOLD\>'|wc -l) -eq 0 ];then
        clusquota_available=0;
        echo "var clusquota_available=0;"
        return;
    fi
    /opt/gridview/clusquota/bin/goldsh ChargeRate Query |grep 'NBM  Queue' > $QUERATE 2>&1
    user_cq_info=$(/opt/gridview/clusquota/bin/gbalance -u $CHECKUSER|grep '\<'$CHECKUSER'\>')
    # user doest not exist
    if [ $(echo $user_cq_info|grep "does not exist"|wc -l) -ne 0 ] || [ "${user_cq_info}" == "" ];then
        echo "var clusquota_available=0;"
        return;
    fi
    cq_user_sec=$(echo ${user_cq_info}|awk '{print $7}')
    cq_user_total_sec=$(echo ${user_cq_info}|awk '{print $3}')
    let varUserCqHour=$cq_user_sec/3600
    let varUserCqTotalHour=$cq_user_total_sec/3600
    echo "var dUserCqSec=$cq_user_sec;"
    echo "var dUserCqHour=$varUserCqHour;"
    echo "var dUserCqTotalSec=$cq_user_total_sec;"
    echo "var dUserCqTotalHour=$varUserCqTotalHour;"
    echo "var clusquota_available=1;"
    clusquota_available=1;
}
get_clusquota_info


queList=`qmgr -c 'p s'|grep 'create queue' |awk '{print $3}'`
#echo var queList=`which qmgr`\;

## print the Accessible Queue list
queAcceList="["
## get the Queue Status
funcQueStat
queAcceList=$queAcceList]
echo var aQueList=$queAcceList\;

## User Home Path
user_home=`finger -mlp $CHECKUSER |head -n2|tail -n1|awk '{print $2}'`
work_dir=$user_home

## Read config file
source ${DIRNAM}/../../CommonConf.setting
source ${DIRNAM}/${PORTALNAM}.setting
if [ -f ${user_home}/.clusportal/${PORTALNAM}.setting ]
then source ${user_home}/.clusportal/${PORTALNAM}.setting
fi

## Read user last setting

PORTALUSERCNF=$QTMPDIR/${PORTALNAM}$QTIMESTAMP
/bin/su - $CHECKUSER -c "if [ -f ${DOLLAR}HOME/.gv_portal/${PORTALNAM}.setting ];then cat ${DOLLAR}HOME/.gv_portal/${PORTALNAM}.setting; fi" > ${PORTALUSERCNF}
source ${PORTALUSERCNF}

## print the disk quota info
if [ $nfs_quota_available -eq 1 ];then
  DSKQUOTAF=$QTMPDIR/diskquotaf$QTIMESTAMP
  DSKUSER=$CHECKUSER
  if [ $DSKUSER = 'root' ];then
    if [ $nfs_root_squash ];then
       DSKUSER='nobody'
    fi
  fi
  quota -uv $DSKUSER |grep "$nfs_quota_filesystem" > $DSKQUOTAF
  diskUsed=`awk '{print $2}' $DSKQUOTAF`
  diskLimits=`awk '{print $3}' $DSKQUOTAF`
  let diskLimitsGb=diskLimits/1048576
  echo var diskfilesystem=\"$nfs_quota_filesystem\"\;
  echo var diskused=$diskUsed\;
  echo var disklimits=$diskLimits\;
  echo var disklimitsgb=$diskLimitsGb\;
  echo var diskquota_available=1\;
else
  echo var diskfilesystem=null\;
  echo var diskused=\"0\"\;
  echo var disklimits=\"0\"\;
  echo var disklimitsgb=\"0\"\;
  echo var diskquota_available=0\;
fi

## print the Selected Queue
if [ -z `echo $queAcceList |grep $queue_default` ];then
	queAcceFirst=`echo $queAcceList |awk -F\" '{print $2}'`
  echo var queSelected=\"$queAcceFirst\"\;
else
  echo var queSelected=\"$queue_default\"\;
fi
echo var UserHomePath=\"`finger -mlp $CHECKUSER |head -n2|tail -n1|awk '{print $2}'`\"\;
echo var userhome=\"`finger -mlp $CHECKUSER |head -n2|tail -n1|awk '{print $2}'`\"\;
echo var numnodes=\"$nnodes_default\"\;
#echo var maxnodes=\"$maxnnodes\"\;
echo var numppn=\"$ppn_default\"\;
#echo var maxppn=\"$maxppn\"\;
echo var name=\"${name_prefix}\"\;
echo var hours=\"$hours_default\"\;
#echo var maxhours=\"$maxhours\"\;
echo var minutes=\"0\"\;
echo var seconds=\"0\"\;

echo var vnc_available=\"$vnc_available\"\;
echo var vnc=\"0\"\;

echo var checkpoint_available=\"$checkpoint_availabel\"\;
echo var checkpoint=\"$checkpoint_default\"\;
echo var checkpoint_def=\"$checkpoint_default\"\;
echo var interval=\"$interval_default\"\;
echo var interval_def=\"$interval_default\"\;
echo var min_interval=\"$min_interval\"\;

echo var mpi_mpi_opt=\"$mpi_mpi_opt\"\;
echo var mpi_pbs_opt=\"$mpi_pbs_opt\"\;
echo var mpi_pre_cmd=\"$mpi_pre_cmd\"\;
echo var mpi_post_cmd=\"$mpi_post_cmd\"\;

rm -rf $QTMPDIR

