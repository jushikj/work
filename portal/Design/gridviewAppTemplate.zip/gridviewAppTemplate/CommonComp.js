
            
            var s_QueStat=new Ext.data.SimpleStore({data:aQueStat,fields:["id","QueName","TotNodes","BusyNodes","FreeNodes","FreeCores", "ChargeRate", "IsQueAcce","MaxPPN","MaxMem","MaxNodes","MaxCores","MaxWalltime","MinNodes","MinCores","MinWalltime"]});

            var s_QueList=new Ext.data.SimpleStore({data:aQueList,fields:["QUEUE"]});

            var strUserCqHour;
            if (clusquota_available == 1) strUserCqHour = dUserCqHour + " CPU*Hours";
            else strUserCqHour = "unlimit";

            var strDiskQuota;
            var fDiskQuota;
            if (diskquota_available == 1)
            {
            	strDiskQuota = diskfilesystem + "   " + disklimitsgb + "GB";
            	fDiskQuota = diskused / disklimits;
            }
            else
            {
            	strDiskQuota = "unlimit";
            	fDiskQuota = 0.0;
            }
            
           var AviResField = new Ext.form.FieldSet(
             { title: 'Available Resource',
                        xtype: 'fieldset',
                        id: 'ResourceSet',
                        anchor: '100%',
                        items: [
                            {
                                xtype: 'grid',
                                id: 'QueStatGrid',
                                height: 160,
                                hideCollapseTool: false,
                                titleCollapse: true,
                                collapsible: true,
                                collapsed: false,
                                width : 745,
                                title: 'Queue Status',
                                store: s_QueStat,
                                columns: [
                                    {
                                        xtype: 'gridcolumn',
                                        dataIndex: 'QueName',
                                        editable: false,
                                        header: 'Queue Name',
                                        sortable: true,
                                        width: 120
                                    },
                                    {
                                        xtype: 'numbercolumn',
                                        align: 'right',
                                        dataIndex: 'TotNodes',
                                        editable: false,
                                        header: 'Total Nodes',
                                        sortable: true,
                                        width: 85,
                                        format: '000000'
                                    },
                                    {
                                        xtype: 'numbercolumn',
                                        align: 'right',
                                        dataIndex: 'BusyNodes',
                                        editable: false,
                                        header: 'Busy Nodes',
                                        sortable: true,
                                        width: 85,
                                        format: '000000'
                                    },
                                    {
                                        xtype: 'numbercolumn',
                                        align: 'right',
                                        dataIndex: 'FreeNodes',
                                        editable: false,
                                        header: 'Free Nodes',
                                        sortable: true,
                                        width: 85,
                                        format: '000000'
                                    },
                                    {
                                        xtype: 'numbercolumn',
                                        align: 'right',
                                        dataIndex: 'FreeCores',
                                        header: 'Free Cores',
                                        sortable: true,
                                        width: 90,
                                        format: '000000'
                                    },
                                    {
                                        xtype: 'numbercolumn',
                                        align: 'right',
                                        dataIndex: 'ChargeRate',
                                        header: 'Charge Rate',
                                        sortable: true,
                                        width: 85
                                    },
                                    {
                                        xtype: 'booleancolumn',
                                        align: 'right',
                                        dataIndex: 'IsQueAcce',
                                        editable: false,
                                        header: 'Accessible',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MaxPPN',
                                        header: 'Max PPN',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MaxMem',
                                        header: 'Max Memory',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MaxNodes',
                                        header: 'Max Nodes',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MaxCores',
                                        header: 'Max Cores',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MaxWalltime',
                                        header: 'Max Walltime',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MinNodes',
                                        header: 'Min Nodes',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MinCores',
                                        header: 'Min Cores',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MinWalltime',
                                        header: 'Min Walltime',
                                        sortable: true,
                                        width: 80
                                    }
                                ]
                            },
                            {
                                xtype: 'spacer',
                                height: 12
                            },
                            {
                                xtype: 'label',
                                text: 'ClusQuota Disk Usage :'
                            },
                            {
                                xtype: 'progress',
                                name: 'dskQuotaBar',
                                id: 'dskQuotaBar',
                                width: 745,
                                text:  strDiskQuota,
                                value: fDiskQuota
                            },
                            {
                                xtype: 'spacer',
                                height: 12
                            },
                            {
                                xtype: 'label',
                                text: 'ClusQuota CPU Time :'
                            },
                            {
                                xtype: 'progress',
                                name: 'cquotaBar',
                                id: 'cquotaBar',
                                width: 745,
                                animate: true,
                                text:  strUserCqHour,
                                value: 0.0
                            }
                        ]
                      } );
                      
           var JobSchField= new Ext.form.FieldSet(
            { 
            	title : "Job Schedule Parameters",
                        layout : "column",
                        hideCollapseTool: false,
                        titleCollapse: true,
                        collapsible: true,
                        autoWidth : true,
                        items : [
                            { layout : "form",
                              columnWidth : .5,
                              labelWidth : 80,
                              items : [
                                  {fieldLabel : 'Nnodes',
                                    xtype : 'numberfield',
                                    labelWidth : 80,
                                    name : 'nnodes',
                                    id : "nnodes",
                                    //maxValue : maxnodes,
                                    allowBlank : false,
                                    allowNegative : false,
                                    allowDecimals : false
                                  },
                                  {fieldLabel : 'Cores/Node',
                                    labelWidth : 80,
                                    xtype : 'numberfield',
                                    name : 'ppn',
                                    id : "ppn",
                                    //maxValue : maxppn,
                                    allowBlank : false,
                                    allowNegative : false,
                                    allowDecimals : false
                                  },
                                  {layout : "column",
                                    fieldLabel : 'Wall Time',
                                    items : [{
                                          name : 'hours',
                                          id : "hours",
                                          xtype : 'numberfield',
                                          width : 45,
                                          //maxValue : maxhours,
                                          allowNegative : false,
                                          allowDecimals : false,
                                          allowBlank : false
                                        },
                                        {
                                          xtype : 'displayfield',
                                          value : 'hh'
                                        },
                                        {
                                          name : 'minutes',
                                          id : "minutes",
                                          xtype : 'numberfield',
                                          width : 24,
                                          maxValue : 59,
                                          allowNegative : false,
                                          allowDecimals : false,
                                          allowBlank : false
                                        },
                                        {
                                          xtype : 'displayfield',
                                          value : 'mm'
                                        },
                                        {
                                          name : 'seconds',
                                          id : "seconds",
                                          xtype : 'numberfield',
                                          width : 24,
                                          maxValue : 59,
                                          allowNegative : false,
                                          allowDecimals : false,
                                          allowBlank : false
                                        },
                                        {
                                          xtype : 'displayfield',
                                          value : 'ss'
                                        }
                                      ]
                                  }

                                ]
                            },
                            { layout : "form",
                              columnWidth : .5,
                              labelWidth : 54,
                              items : [
                                  {fieldLabel : 'Queue',
                                    width : 200,
                                    xtype : 'combo',
                                    mode : 'local',
                                    id : 'queue',
                                    value : queSelected,
                                    triggerAction : 'all',
                                    forceSelection : true,
                                    editable : false,
                                    name : 'queue',
                                    valueField : 'QUEUE',
                                    displayField : 'QUEUE',
                                    store : s_QueList
                                  },
                                  {fieldLabel : 'Name',
                                    width : 200,
                                    xtype : 'textfield',
                                    name : 'name',
                                    id : "name",
                                    allowBlank : false
                                  },
                                  {
                                    xtype : 'button',
                                    text : 'Manage Job File',
                                    id : 'winscp',// iconCls:"plusAnimation",
                                    handler : function() {
                                    coreSoftwareOpen("winscp",currentAddr,UserHomePath);
                                    }
                                  }
                                ]
                            }
                        ]
                      }); 
           var VncField= new Ext.form.FieldSet(
                       { title: 'Remote Visualization Parameters',
                          xtype: 'fieldset',
                          hideCollapseTool: false,
                          titleCollapse: true,
                          collapsible: true,
                          collapsed: true,
                          id: "vncField",
                          layout: 'column',
                          items: [
                           { layout : 'form',
                          columnWidth : .3,
                          items : [
                              {
                                  fieldLabel: 'VNC Connection',
                                  labelWidth: 80,
                                  xtype: 'checkbox',
                                  id: 'IsVNC',
                                  name: 'IsVNC',
                                  boxLabel: 'Yes',
                                  columnWidth: 0.3
                              }
                          ]}
                         ]
                      }
           );
           
           
/*** ****************************CheckPoint Parameter*************************************/           
           var CRField= new Ext.form.FieldSet(
                       { title : "Checkpoint/Restart Parameters",
                        layout : "column",
                        xtype : 'fieldset',
                        id : 'CRField',
                        hideCollapseTool: false,
                        titleCollapse: true,
                        collapsible: true,
                        collapsed: true,
                        autoWidth : true,
                        items : [
                        { layout : 'form',
                          columnWidth : .4,
                          items : [
                                   { 
                                     labelWidth : 80,
                                     fieldLabel: 'Auto Checkpoint',
                                   	 xtype: 'checkbox',
                                         id: 'checkpoint',
                                         name: 'checkpoint',
                                         boxLabel: 'Yes',
                                         inputValue : 'Yes',
                                         checked: false
                                   }
                                 ]
                        },
                        {
                          layout : "form",
                          columnWidth : .6,
                          items : [{
                            fieldLabel : 'Interval(minutes)',
                                  name : 'interval',
                                  xtype : 'numberfield',
                                  id : 'interval',
                                  width : 50,
                                  maxValue : 4320,
                                  minValue : min_interval,
                                  allowNegative : false,
                                  allowDecimals : false,
                                  allowBlank : false
                                }]
                              }           
                       ]
                      });
                      
                      
                      
                      
           var AdvField1 =  new Ext.form.FieldSet(
           { title: 'Advanced Parameters',
                          xtype: 'fieldset',
                          autoHeight: true,
                          hideCollapseTool: false,
                          titleCollapse: true,
                          collapsible: true,
                          collapsed: true,
                          items: [
                              { layout : 'column',
                            items : [
                               {
 				  layout : 'form',
				  columnWidth : .7,
				  items : [
				  {
                                      xtype: 'textarea',
                                      id: 'mpiAdvOpt',
                                      height: 60,
                                      name: 'mpiAdvOpt',
                                      anchor: '95%',
                                      fieldLabel: 'MPI Options'
                                  }]
                              },
                                { columnWidth : .3,
                                  xtype: 'label',
                                   id: 'explain11',
                                   name: 'explain11',
                                   html: 'eg. "-show-progress"'
                                }
                              ]
                             },
                               { layout : 'column',
                            items : [
                               {
 				  layout : 'form',
				  columnWidth : .7,
				  items : [
				  {
                                      xtype: 'textarea',
                                      id: 'pbsAdvOpt',
                                      height: 60,
                                      name: 'pbsAdvOpt',
                                      anchor: '95%',
                                      fieldLabel: 'PBS Options'
                                  }]
                              },
                                { columnWidth : .3,
                                  xtype: 'label',
                                   id: 'explain11',
                                   name: 'explain11',
                                   html: 'eg. "-l mem=30MB" <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"-V"'
                                }
                              ]
                             },
                              {   layout : 'column',
                               items : [
                               {
 				  layout : 'form',
				  columnWidth : .7,
				  items : [
				  {
                                      xtype: 'textarea',
                                      id: 'preCommands',
                                      height: 60,
                                      name: 'preCommands',
                                      anchor: '95%',
                                      fieldLabel: 'Pre Commands'
                                  }]
                              },
                                { columnWidth : .3,
                                  xtype: 'label',
                                   id: 'explain22',
                                   name: 'explain22',
                                   html: 'eg. echo begin time is `date` | tee -a ***.txt'
                                }
                              ]
                             },
                              {   layout : 'column',
                               items : [
                               {
 				  layout : 'form',
				  columnWidth : .7,
				  items : [
				  {
                                      xtype: 'textarea',
                                      id: 'postCommands',
                                      height: 60,
                                      name: 'postCommands',
                                      anchor: '95%',
                                      fieldLabel: 'Post Commands'
                                  }]
                              },
                                { columnWidth : .3,
                                  xtype: 'label',
                                   id: 'explain33',
                                   name: 'explain33',
                                   html: 'eg. echo end time is `date` | tee -a ***.txt'
                                }
                              ]
                             }
                          ]
                      } );

           var AdvField2 =  new Ext.form.FieldSet(
           { title: 'Advanced Parameters',
                          xtype: 'fieldset',
                          autoHeight: true,
                          hideCollapseTool: false,
                          titleCollapse: true,
                          collapsible: true,
                          collapsed: true,
                          items: [
                              { layout : 'column',
                            items : [
                               {
 				  layout : 'form',
				  columnWidth : .7,
				  items : [
				  {
                                      xtype: 'textarea',
                                      id: 'pbsAdvOpt2',
                                      height: 60,
                                      name: 'pbsAdvOpt2',
                                      anchor: '95%',
                                      fieldLabel: 'PBS Options'
                                  }]
                              },
                                { columnWidth : .3,
                                  xtype: 'label',
                                   id: 'explain11',
                                   name: 'explain11',
                                   html: 'eg. "-l mem=30MB" <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"-V"'
                                }
                              ]
                             },		      
                              {   layout : 'column',
                               items : [
                               {
 				  layout : 'form',
				  columnWidth : .7,
				  items : [
				  {
                                      xtype: 'textarea',
                                      id: 'preCommands2',
                                      height: 60,
                                      name: 'preCommands2',
                                      anchor: '95%',
                                      fieldLabel: 'Pre Commands'
                                  }]
                              },
                                { columnWidth : .3,
                                  xtype: 'label',
                                   id: 'explain22',
                                   name: 'explain22',
                                   html: 'eg. echo begin time is `date` | tee -a ***.txt'
                                }
                              ]
                             },
                              {   layout : 'column',
                               items : [
                               {
 				  layout : 'form',
				  columnWidth : .7,
				  items : [
				  {
                                      xtype: 'textarea',
                                      id: 'postCommands2',
                                      height: 60,
                                      name: 'postCommands2',
                                      anchor: '95%',
                                      fieldLabel: 'Post Commands'
                                  }]
                              },
                                { columnWidth : .3,
                                  xtype: 'label',
                                   id: 'explain33',
                                   name: 'explain33',
                                   html: 'eg. echo end time is `date` | tee -a ***.txt'
                                }
                              ]
                             }
                          ]
                      } );

