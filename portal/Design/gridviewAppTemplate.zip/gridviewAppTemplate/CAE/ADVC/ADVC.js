﻿Ext.onReady(function() {
    var currentAddr;
    var AddrSplit;
    currentAddr = location.host;
    AddrSplit = currentAddr.split(":");
    currentAddr = AddrSplit[0];

    /*********************Run Parameter*************************************/

    var RunField = new Ext.form.FieldSet({
        title: "Run Parameters",
        /*******************************Run Parameter*************************************/
        layout: "form",
        xtype: 'fieldset',
        autoWidth: true,
        hideCollapseTool: false,
        titleCollapse: true,
        collapsible: true,
        labelWidth: 80,
        items: [{
                layout: 'column',
                items: [{
                        layout: 'form',
                        columnWidth: .6,
                        items: [{
    /*********************Program run file*************************************/
                                fieldLabel: 'ADVC Program',
                                xtype: 'combo',
                                width: 340,
                                mode: 'local',
                                id: 'program',
                                value: program,
                                triggerAction: 'all',
                                forceSelection: false,
                                editable: true,
                                name: 'program',
                                displayField: 'MPIPROG',
                                valueField: 'MPIPROG',
                                store: s_prog
                            }
                        ]
                    }, {
                        xtype: 'button',
                        columnWidth: .1,
                        text: "Browse...",
                        handler: function() {
                            file = Ext.getCmp("program").getValue();
                            var filePath = fileDir(file);
                            openFile("program", filePath);
                        }
                    }
                ]
            },{
                layout: "column",
                //width: 450,
                autoWidth: true,
                items: [{
    /*********************MPI TYPE*************************************/
                        layout: "form",
                        columnWidth: 0.3,
                        //labelWidth: 100,
                        items: [{
                                fieldLabel: 'MPI Type',
                                id: 'mpitype',
                                xtype: 'combo',
                                mode: 'local',
                                width: 100,
                                value: mpitype,
                                triggerAction: 'all',
                                forceSelection: true,
                                editable: false,
                                name: 'mpitype',
                                displayField: 'MPI',
                                valueField: 'MPI',
                                store: s_mpi
                            }
                        ]
                    },{
    /*********************TCP/IB*************************************/
                        layout: 'form',
                        columnWidth: 0.45,
                        //labelWidth: 1000,
                        autoWidth: false,
                        items: [{
                                fieldLabel: 'Commucation',
                                xtype: 'radiogroup',
                                id: 'commucation',
                                //width: 200,
                                items: [{
                                        boxLabel: 'Infiniband',
                                        name: 'network',
                                        id: 'ib',
                                        inputValue: 'ib',
                                        checked: true
                                    }, {
                                        boxLabel: 'GigabitEther',
                                        name: 'network',
                                        id: 'tcp',
                                        inputValue: 'tcp'
                                    }
                                ]
                            }
                        ]
                    }, {
    /*********************CPU Bind*************************************/
                        xtype: 'checkbox',
                        columnWidth: .1,
                        //width: 100,
                        autoWidth: true,
                        id: 'cpuBind',
                        name: 'cpuBind',
                        boxLabel: 'CPU Binding',
                        inputValue: 'cpuBind',
                        checked: true
                    }
                ]
            },  {
    /*********************Arguments*************************************/
                fieldLabel: 'Arguments',
                width: 340,
                xtype: 'textfield',
                name: 'programarg',
                id: "programarg",
                allowBlank: true
            }, {
                layout: 'column',
                items: [{
                        layout: 'form',
                        columnWidth: .6,
                        items: [{
    /*********************Workding Dir*************************************/
                                fieldLabel: 'Working DIR',
                                width: 340,
                                xtype: 'textfield',
                                name: 'workdir',
                                id: "workdir",
                                allowBlank: false
                            }
                        ]
                    }, {
                        columnWidth: .1,
                        xtype: 'button',
                        text: "Browse...",
                        id: "PathBtn",
                        handler: function() {
                            var filePath = Ext.getCmp("workdir").getValue();
                            openPath("workdir", filePath);
                        }
                    }
                ]
            }, {
                layout: 'column',
                items: [{
                        layout: 'form',
                        columnWidth: .6,
                        items: [{
    /*********************Input File*************************************/
                                fieldLabel: 'Input File',
                                width: 340,
                                xtype: 'textfield',
                                name: 'inputfile',
                                id: "inputfile",
                                allowBlank: false
                            }
                        ]
                    }, {
                        columnWidth: .1,
                        xtype: 'button',
                        text: "Browse...",
                        id: "PathBtn",
                        handler: function() {
                            var filePath = Ext.getCmp("workdir").getValue();
                            openFile("inputfile", filePath);
                        }
                    }
                ]
            },{
    /*********************Log file*************************************/
                fieldLabel: 'Log File',
                xtype: 'textfield',
                width: 340,
                name: 'output',
                id: "output",
                allowBlank: false
            }
        ]
    });
    var simple = new Ext.FormPanel({
        labelAlign: 'left',
        frame: true,
        title: portal_strAppName + " Portal v" + portal_version,
        layout: "form",
        id: "simple",
        bodyStyle: 'padding:5px 5px 0',
        width: 800,
        buttonAlign: "center",
        items: [{
                xtype: 'panel',
                border: false,
                html: '<p align="center"><img src="' + imgName + '"/></p>'
            },
            AviResField,
            JobSchField,
            RunField,
            VncField,
            CRField,
            AdvField1
        ],

        buttons: [{
                text: 'Submit',
                id: 'submit',
                handler: mySubmit
            }, {
                text: 'Reset',
                id: 'resetting',
                // iconCls:'freshbutton',
                handler: function() {
                    simple.getForm().reset();
                    formAllReset();
                }
            }
        ]
    });


    var tmpPanel = new Ext.Panel({
        renderTo: Ext.getBody(),
        autoScroll: true,
        layout: "column",
        width: 1150,
        bodyStyle: 'padding-left:15px;padding-bottom:30px',
        frame: true,
        items: [{
                layout: "form",
                columnWidth: .73,
                items: [simple]
            }, {
                layout: "form",
                items: [introTips, resTips, jobTips, runTips, vncTips, crTips, advTips1]
            }
        ]
    });
    tmpPanel.show();



    formAllReset();

    formRefresh();


});
