var introTips = new Ext.Panel({
    autoScroll: true,
    width: 280,
    html: '<p><br/>ADVC Solver 是ADVC中对结构和热力传输进行分析模块，具有比较好的并行扩展性.\
    该程序目前支持platform_mpi，MPICH2等并行环境。</p><p>&nbsp;</p>',
    title: 'Introduction',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true,
    collapsible: true,
    collapsed: false
});



var runTips = new Ext.Panel({
    autoScroll: true,
    width: 280,
    html: '<p><br />ADVC Program:<br /><br />请选择ADVC Solver所在的路径，如果ADVCSolver已在系统环境变量内，可直接使用该命令</p> \
    <p><br />MPI Type:<br /><br />选择运行该作业时使用的MPI环境，默认是platform_mpi，如果您在advc配置中已更改MPI类型，请在该处选择对应的MPI。\
    </p><p><br />Commucation:<br /><br />多节点并行任务，节点之间数据交换采用何种网络。默认环境下，系统会自动选择MPI通讯网络</p> \
    <p><br />Cpu Bind:<br /><br />选择运行作业时是否进程绑定CPU。</p>\
    <p><br />Arguments:<br /><br />如果ADVC应用程序运行时需要提供自定义的参数，请在此输入。</p>\
    <p><br />Working DIR:<br /><br />本次计算任务的工作目录。</p> \
    <p><br />Input DIR:<br /><br />本次计算所需要的输入文件。</p> \
    <p><br />Input File:<br /><br />计算过程中的标准输出和标准错误输出信息，将被重定向保存为文件。</p><p>&nbsp;</p>',
    title: 'Run Tips',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true,
    collapsible: true,
    collapsed: true
});
