prefix1=example3
prefix2=mpi
for i in js  jsp  run  setting  png  check  func.js  help.js;do
mv ${prefix1}.${i} ${prefix2}.${i}
done
 
