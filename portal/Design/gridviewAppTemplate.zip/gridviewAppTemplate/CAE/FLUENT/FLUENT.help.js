var introTips = new Ext.Panel({
    autoScroll: true,
    width: 280,
    html: '<p><br/>Fluent为业界最通用计算流体力学(CFD)软件包，用来模拟从不可压缩到高度可压缩范围内的复杂流动。\
    由于采用了多种求解方法和多重网格加速收敛技术，因而FLUENT能达到最佳的收敛速度和求解精度。灵活的非结构化网格 \
    和基于解的自适应网格技术及成熟的物理模型，使FLUENT在转捩与湍流、传热与相变、化学反应与燃烧、多相流、旋转机械、\
    动/变形网格、噪声、材料加工、燃料电池等方面有广泛应用。目前Fluent被Ansys公司收购，加入了Ansys软件的大家庭。</p><p>&nbsp;</p>',
    title: 'Introduction',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true,
    collapsible: true,
    collapsed: false
});



var runTips = new Ext.Panel({
    autoScroll: true,
    width: 280,
    html: '<p><br />MPI Type:<br /><br /选择FLUENT的可执行文件。\
    <p><br />Version:<br /><br />选择Fluent计算算例的类型，分为2d,3d,2ddp,3ddp 等等。\
    </p><p><br />MPI Type:<br /><br />并行计算时，选择使用的MPI类型，分为HP mpi，Intel mpi或openmpi，建议使用效率最高的默认的HP mpi。\
    </p><p><br />Remote Shell:<br /><br />多节点并行任务，节点之间的访问模式。建议采用默认的SSH模式。\
    </p><p><br />Arguments:<br /><br />Fluent的其它选项，默认为空。\
    </p><p><br />Working DIR:<br /><br />本次计算任务的工作目录。\
    </p><p><br />Input File:<br /><br />Fluent的输入控制文件。\
    </p><p><br />Output File:<br /><br />计算过程中的标准输出和标准错误输出信息，将被重定向保存为文件。</p>\
    <p>&nbsp;</p>',
    title: 'Run Tips',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true,
    collapsible: true,
    collapsed: true
});