﻿    Ext.onReady(function() {

        // turn on validation errors beside the field globally
        Ext.form.Field.prototype.msgTarget = 'under';

        /** ******************WinSCP地址传递(通过读取浏览器地址)************************** */

        // coreSoftwareOpen("winscp", 集群管理节点ip, UserHomePath)
        // 传递ip参数为：
        // 1.portal_strJobManagerAddr 通过gridview传递
        // 2.currentAddr 通过读取浏览器地址
        var currentAddr;
        var AddrSplit;
        currentAddr = location.host;
        AddrSplit = currentAddr.split(":");
        currentAddr = AddrSplit[0];

        /*********************Run Parameter*************************************/

        var RunField = new Ext.form.FieldSet({
            title: "Run Parameters",
            /*******************************Run Parameter*************************************/
            layout: "form",
            xtype: 'fieldset',
            autoWidth: true,
            hideCollapseTool: false,
            titleCollapse: true,
            collapsible: true,
            labelWidth: 80,
            items: [{
                    layout: 'column',
                    items: [{
                            layout: 'form',
                            columnWidth: .6,
                            items: [{
                                    fieldLabel: 'NASTRAN Bin',
                                    xtype: 'combo',
                                    width: 340,
                                    mode: 'local',
                                    id: 'program',
                                    value: program,
                                    triggerAction: 'all',
                                    forceSelection: true,
                                    editable: false,
                                    name: 'program',
                                    store: s_prog
                                }
                            ]
                        }, {
                            layout: 'column',
                            columnWidth: .15,
                            items: [{
                                    xtype: 'button',
                                    columnWidth: .667,
                                    text: "Browse...",
                                    handler: function() {
                                        var file = Ext.getCmp("program").getValue();
                                        var filePath = fileDir(file);
                                        openFile("program", filePath);
                                    }
                                }
                            ]
                        }
                    ]
                }, {
                    layout: "column",
                    width: 450,
                    autoWidth: true,
                    items: [{
                            layout: "form",
                            columnWidth: .6,
                            labelWidth: 80,
                            items: [{
                                    fieldLabel: 'Run Mode',
                                    xtype: 'radiogroup',
                                    id: 'mode',
                                    items: [{
                                            boxLabel: 'Serial',
                                            name: 'mode',
                                            id: 'serial'
                                        }, {
                                            boxLabel: 'Local',
                                            name: 'mode',
                                            id: 'local',
                                            checked: true
                                        }, {
                                            boxLabel: 'Distribute',
                                            name: 'mode',
                                            id: 'distribute',
                                            checked: true
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }, {
                    layout: "column",
                    width: 450,
                    autoWidth: true,
                    items: [{
                            layout: "form",
                            columnWidth: .4,
                            items: [{
                                    fieldLabel: 'HPC run',
                                    xtype: 'radiogroup',
                                    //width : 145,
                                    id: 'hpcRun',
                                    items: [{
                                            boxLabel: 'MPP',
                                            name: 'paramode',
                                            id: 'dmp',
                                            inputValue: 'dmp',
                                            checked: true
                                        }, {
                                            boxLabel: 'SMP',
                                            name: 'paramode',
                                            id: 'smp',
                                            inputValue: 'smp'
                                        }
                                    ]
                                }
                            ]
                        }, {
                            layout: "form",
                            columnWidth: .4,
                            //labelWidth : 80,
                            items: [{
                                    fieldLabel: 'Remote Shell',
                                    xtype: 'radiogroup',
                                    id: 'remoteShell',
                                    items: [{
                                            boxLabel: 'RSH',
                                            name: 'sh',
                                            id: 'rsh',
                                            inputValue: 'RSH'
                                        }, {
                                            boxLabel: 'SSH',
                                            name: 'sh',
                                            id: 'ssh',
                                            inputValue: 'SSH',
                                            checked: true
                                        }
                                    ]
                                }

                            ]
                        }
                    ]
                }, {
                    layout: "column",
                    width: 450,
                    autoWidth: true,
                    items: [{
                            layout: "form",
                            columnWidth: .2,
                            items: [{
                                    xtype: 'checkbox',
                                    id: 'hpmpi',
                                    name: 'hpMpi',
                                    boxLabel: 'HP MPI',
                                    inputValue: 'hpmpi',
                                    checked: true
                                }
                            ]
                        }, {
                            layout: "form",
                            columnWidth: .2,
                            items: [{
                                    xtype: 'checkbox',
                                    id: 'bat',
                                    name: 'bat',
                                    boxLabel: 'BAT',
                                    inputValue: 'bat',
                                    checked: false
                                }
                            ]
                        }, {
                            layout: "form",
                            columnWidth: .2,
                            items: [{
                                    xtype: 'checkbox',
                                    id: 'scr',
                                    name: 'scr',
                                    boxLabel: 'SCR',
                                    inputValue: 'scr',
                                    checked: true
                                }
                            ]
                        }
                    ]
                }, {
                    fieldLabel: 'Arguments',
                    width: 340,
                    xtype: 'textfield',
                    name: 'programarg',
                    id: "programarg",
                    allowBlank: true
                }, {
                    layout: 'column',
                    items: [{
                            layout: 'form',
                            columnWidth: .6,
                            items: [{
                                    fieldLabel: 'Working DIR',
                                    width: 340,
                                    xtype: 'textfield',
                                    name: 'workdir',
                                    id: "workdir",
                                    allowBlank: false
                                }
                            ]
                        }, {
                            columnWidth: .1,
                            xtype: 'button',
                            text: "Browse...",
                            id: "PathBtn",
                            handler: function() {
                                var filePath = Ext.getCmp("workdir").getValue();
                                openPath("workdir", filePath);
                            }
                        }
                    ]
                }, {
                    layout: 'column',
                    items: [{
                            layout: 'form',
                            columnWidth: .6,
                            items: [{
                                    fieldLabel: 'Input File',
                                    width: 340,
                                    xtype: 'textfield',
                                    name: 'inputFile',
                                    id: "inputFile",
                                    allowBlank: true
                                }
                            ]
                        }, {
                            columnWidth: .1,
                            xtype: 'button',
                            text: "Browse...",
                            id: "InputFileBtn",
                            handler: function() {
                                var filePath = Ext.getCmp("workdir").getValue();
                                openFile("inputFile", filePath);
                            }
                        }
                    ]
                }, {
                    fieldLabel: 'Output File',
                    xtype: 'textfield',
                    width: 340,
                    name: 'output',
                    id: "output",
                    allowBlank: false
                }
            ]
        });
        var simple = new Ext.FormPanel({
            labelAlign: 'left',
            frame: true,
            title: portal_strAppName + " Portal v" + portal_version,
            layout: "form",
            id: "simple",
            bodyStyle: 'padding:5px 5px 0',
            width: 800,
            buttonAlign: "center",
            items: [{
                    xtype: 'panel',
                    border: false,
                    html: '<p align="center"><img src=NASTRAN.png /></p>'
                },
                AviResField,
                JobSchField,
                RunField,
                CRField,
                AdvField2
            ],

            buttons: [{
                    text: 'Submit',
                    id: 'submit',
                    handler: mySubmit
                }, {
                    text: 'Reset',
                    id: 'resetting',
                    // iconCls:'freshbutton',
                    handler: function() {
                        simple.getForm().reset();
                        formAllReset();
                    }
                }
            ]
        });


        var tmpPanel = new Ext.Panel({
            renderTo: Ext.getBody(),
            autoScroll: true,
            layout: "column",
            width: 1150,
            bodyStyle: 'padding-left:15px;padding-bottom:30px',
            frame: true,
            items: [{
                    layout: "form",
                    columnWidth: .73,
                    items: [simple]
                }, {
                    layout: "form",
                    items: [introTips, resTips, jobTips, runTips, vncTips, crTips, advTips1]
                }
            ]
        });
        tmpPanel.show();



        formAllReset();

        formRefresh();


    });