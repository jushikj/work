prefix1=FLUENT
prefix2=CFX
for i in js  jsp  run  setting  png  check  func.js  help.js;do
mv ${prefix1}.${i} ${prefix2}.${i}
done
 
