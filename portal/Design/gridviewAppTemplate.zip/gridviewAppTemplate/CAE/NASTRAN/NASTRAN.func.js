﻿/*!
 * Ext JS Library 3.3.0
 * Copyright(c) 2006-2010 Ext JS, Inc.
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
/**
 * 从/opt/gridview/software/下载指定名称的软件
 *
 * @param {}
 *            softwareName
 */
/*

/** 提交函数 */

function mySubmit() {
    var gap_mode, gap_paramode, gap_remote_sh;

    // serial or parallel
    if (Ext.getDom("serial").checked == true)
        gap_mode = 'Serial';
    else if (Ext.getDom("local").checked == true)
        gap_mode = 'Local';
    else
        gap_mode = 'Distribute';

    //set HPC run type
    if (Ext.getCmp("dmp").getValue() == true)
        gap_paramode = 'dmp';
    else
        gap_paramode = 'smp';

    // set remote sh type
    if (Ext.getCmp("rsh").getValue() == true)
        gap_remote_sh = 'rsh';
    else
        gap_remote_sh = 'ssh';
    /** ************************************************************************************ */

    if (!Ext.getCmp("simple").getForm().isValid())
        Ext.MessageBox.alert('提醒', '对不起，您提交的信息有误！', "");
    else if (Ext.getCmp("nnodes").getValue() * Ext.getCmp("ppn").getValue() * (Ext.getCmp("hours").getValue() * 3600 + Ext.getCmp("minutes").getValue() * 60 + Ext.getCmp("seconds").getValue()) > dUserCqSec)
        Ext.MessageBox.alert('提醒', '对不起，您申请的机时资源超过配额，请减少Walltime的值！', "");
    else
        Ext.Ajax.request({
            url: "/jm_as/appsubmit/submitAppJob.action",
            // method:"post",
            scope: this,
            // waitMsg:"查询中,请稍后！",
            params: {
                strJobManagerID: portal_strJobManagerID,
                strJobManagerAddr: portal_strJobManagerAddr,
                strJobManagerPort: portal_strJobManagerPort,
                strJobManagerType: portal_strJobManagerType,
                strAppType: portal_strAppType,
                strAppName: portal_strAppName,
                strOSUser: portal_strOsUser,
                strKeyWord: "k1;k2;;;;",
                strRemark: "remarktest",
                mapAppJobInfo: Ext.util.JSON.encode({
                    "GAP_NNODES": Ext.getCmp("nnodes").getValue(),
                    "GAP_PPN": Ext.getCmp("ppn").getValue(),
                    "GAP_WALL_TIME": Ext.getCmp("hours").getValue() + ":" + Ext.getCmp("minutes").getValue() + ":" + Ext.getCmp("seconds").getValue(),
                    "GAP_QUEUE": Ext.getCmp("queue").getValue(),
                    "GAP_NAME": Ext.getCmp("name").getValue(),

                    "GAP_PROGRAM": "\'" + Ext.getCmp("program").getValue() + "\'",
                    "GAP_MODE": gap_mode,
                    "GAP_HPMPI": Ext.getCmp('hpmpi').checked,
                    "GAP_BAT": Ext.getCmp('bat').checked,
                    "GAP_SCR": Ext.getCmp('scr').checked,
                    "GAP_PARAMODE": gap_paramode,
                    "GAP_REMOTE_SHELL": gap_remote_sh,

                    "GAP_PROGRAM_ARG": "\'" + Ext.getCmp("programarg").getValue() + "\'",
                    "GAP_WORK_DIR": "\'" + Ext.getCmp("workdir").getValue() + "\'",
                    "GAP_INPUT": "\'" + Ext.getCmp("inputFile").getValue() + "\'",
                    "GAP_OUTPUT": Ext.getCmp("output").getValue(),

                    "GAP_VNC": Ext.getCmp('IsVNC').getValue(),

                    "GAP_CKECK_POINT": Ext.getCmp('checkpoint').getValue(),
                    "GAP_INTERVAL": Ext.getCmp('interval').getValue(),

                    "GAP_PBS_OPT": "\'" + Ext.getCmp("pbsAdvOpt2").getValue().replace(/\n/ig, '...') + "\'",
                    "GAP_PRE_CMD": "\'" + Ext.getCmp("preCommands2").getValue().replace(/\n/ig, '...') + "\'",
                    "GAP_POST_CMD": "\'" + Ext.getCmp("postCommands2").getValue().replace(/\n/ig, '...') + "\'"
                })
            },

            success: function(response, options) {
                try {
                    var result = Ext.util.JSON.decode(response.responseText);

                    if (result.exitVal == 0) {
                        var resultStr = "Job submitted successfully！<br/><br/>Job ID：" + result.stdOut;

                        Ext.MessageBox.show({
                            title: "Success",
                            msg: resultStr,
                            buttons: Ext.MessageBox.OK,
                            icon: Ext.MessageBox.INFO
                        });
                        var currDate = new Date();
                        var timeStamp = currDate.format('md_His');
                        Ext.getCmp("name").setValue(name + '_' + timeStamp);
                        Ext.getCmp("output").setValue(output + '_' + timeStamp + '.txt');
                    } else {
                        var resultStr = "Job submitting failed！<br/><br/>" + result.stdOut + "<br/><br/>" + result.stdErr;
                        Ext.MessageBox.show({
                            title: "Error",
                            msg: resultStr,
                            buttons: Ext.MessageBox.OK,
                            icon: Ext.MessageBox.ERROR
                        });
                    }
                } catch (e) {}
            },

            failure: function(response, options) {
                var resultStr = "表单提交失败！";
                Ext.MessageBox.show({
                    title: "Error",
                    msg: resultStr,
                    buttons: Ext.MessageBox.OK,
                    icon: Ext.MessageBox.ERROR
                });
            }
        });
}

function ModeRelateRefresh(par_nnodes, par_ppn) {
    if (par_nnodes == 1) {
        if (par_ppn == 1) {
            Ext.getCmp("serial").enable();
            Ext.getDom("serial").checked = true;
            Ext.getCmp("local").disable();
            Ext.getCmp("distribute").disable();
            Ext.getCmp("hpmpi").disable();
            Ext.getCmp("dmp").disable();
            Ext.getCmp("smp").disable();
            Ext.getCmp("ssh").disable();
            Ext.getCmp("rsh").disable();
        } else {
            Ext.getCmp("serial").disable();
            Ext.getCmp("local").enable();
            Ext.getDom("local").checked = true;
            Ext.getCmp("distribute").enable();
            Ext.getCmp("hpmpi").enable();
            Ext.getCmp("dmp").enable();
            Ext.getCmp("smp").enable();
            Ext.getDom("smp").checked = true;
            Ext.getCmp("ssh").enable();
            Ext.getCmp("rsh").enable();
        }
    } else {
        Ext.getCmp("serial").disable();
        Ext.getCmp("local").disable();
        Ext.getCmp("distribute").enable();
        Ext.getDom("distribute").checked = true;
        Ext.getCmp("hpmpi").enable();
        Ext.getDom("hpmpi").checked = true;
        Ext.getCmp("dmp").enable();
        Ext.getDom("dmp").checked = true;
        Ext.getCmp("smp").enable();
        Ext.getCmp("ssh").enable();
        Ext.getCmp("rsh").enable();
    }
}


/*** 页面初始化和页面重置***/

function formAllReset() {

    var currDate = new Date();
    var timeStamp = currDate.format('md_His');

    var name2 = name + '_' + timeStamp;
    setJobSch(numnodes, numppn, hours, minutes, seconds, queSelected, name2);
    queueRelateRefresh();

    var output2 = output + '_' + timeStamp + '.txt';
    setRunCommon(program, workdir, output2);
    ModeRelateRefresh(numnodes, numppn);
    Ext.getCmp("remoteShell").setValue(remoteshell);
    Ext.getCmp("programarg").setValue(programarg);
    Ext.getCmp("inputFile").setValue("");

    setVnc(vnc_available, vnc);
    setCRVisual(checkpoint_available, checkpoint_def, interval_def);

    setAdv2("", "", "");

    if (clusquota_available == 1) cquotaBarRefresh();
}

/*** 页面动态更新***/

function formRefresh() {

    Ext.getCmp("nnodes").on("change", function() {
        //jobScriptRefresh();
        if (clusquota_available == 1) cquotaBarRefresh();
        numnodes = Ext.getCmp("nnodes").getValue();
        numppn = Ext.getCmp("ppn").getValue();
        ModeRelateRefresh(numnodes, numppn);
    });

    Ext.getCmp("ppn").on("change", function() {
        //jobScriptRefresh();

        maxNNodes = totQueNodes; //total nodes in queue, value defined by last queueRelateRefresh()

        if (maxQueNodes != 'unlimit') {
            //max nodes allowed
            if (maxNNodes > maxQueNodes) maxNNodes = maxQueNodes;
        }

        if (maxQueCores != 'unlimit') //max cores allowed
        {
            tmpNNodes = maxQueCores / Ext.getCmp("ppn").getValue();
            if (maxNNodes > tmpNNodes) maxNNodes = tmpNNodes;
        }

        Ext.getCmp("nnodes").setMaxValue(maxNNodes);

        if (clusquota_available == 1) cquotaBarRefresh();
        numnodes = Ext.getCmp("nnodes").getValue();
        numppn = Ext.getCmp("ppn").getValue();
        ModeRelateRefresh(numnodes, numppn);
    });

    Ext.getCmp("hours").on("change", function() {
        if (clusquota_available == 1) cquotaBarRefresh();
    });


    Ext.getCmp("checkpoint").on('check', function() {
        if (Ext.getCmp("checkpoint").getValue() == false) {
            Ext.getCmp("interval").disable();
        } else {
            Ext.getCmp("interval").enable();
        }
    });



    Ext.getCmp("queue").on('select', function() {
        queueRelateRefresh();
        if (clusquota_available == 1) cquotaBarRefresh();
        numnodes = Ext.getCmp("nnodes").getValue();
        numppn = Ext.getCmp("ppn").getValue();
        ModeRelateRefresh(numnodes, numppn);
    });
    Ext.getCmp("IsVNC").on('check', function() {
        if (Ext.getCmp("IsVNC").getValue() == true) {
            Ext.getCmp("mode").disable();
            Ext.getCmp("hpmpi").disable();
            Ext.getCmp("local").disable();
            Ext.getCmp("serial").disable();
            Ext.getCmp("distrubute").disable();
            Ext.getCmp("smp").disable();
            Ext.getCmp("dmp").disable();
            //Ext.getCmp("method").disable();
            //Ext.getCmp("precision").disable();
            Ext.getCmp("inputFile").disable();
            Ext.getCmp("InputFileBtn").disable();
            Ext.getCmp("programarg").disable();
            resultStr = "警告！！当您启动图形界面的CFX进行作业时，请选择那些作业调度分配给您的节点进行计算，这些节点的信息可以在 作业调度-作业管理-执行主机 页面进行查询";
            Ext.MessageBox.show({
                title: "Warning!!",
                msg: resultStr,
                buttons: Ext.MessageBox.OK,
                icon: Ext.MessageBox.INFO
            });

        } else {
            Ext.getCmp("mode").enable();
            //Ext.getCmp("method").enable();
            Ext.getCmp("inputFile").enable();
            Ext.getCmp("InputFileBtn").enable();
            Ext.getCmp("programarg").enable();
            numnodes = Ext.getCmp("nnodes").getValue();
            numppn = Ext.getCmp("ppn").getValue();
            ModeRelateRefresh(numnodes, numppn);
        }
    });

}