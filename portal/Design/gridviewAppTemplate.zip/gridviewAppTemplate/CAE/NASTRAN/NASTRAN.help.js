var introTips = new Ext.Panel({
    autoScroll: true,
    width: 280,
    html: '<p><br/>NASTRAN是在1966年美国国家航空航天局为了满足当时航空航天工业对结构分析的迫切需求主持开发大型应用有限元程序。\
    软件主要包括的分析功能有静力分析、屈曲分析、动力学分析、自动部件模态综合法–ACMS、热分析、气动弹性及颤振分析、\
    流-固耦合分析、多级超单元分析、Krylov 求解器、高级对称分析、\
    设计灵敏度及优化分析、复合材料分析、转子动力学特性分析等。<p>&nbsp;</p>',
    title: 'Introduction',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true,
    collapsible: true,
    collapsed: false
});



var runTips = new Ext.Panel({
    autoScroll: true,
    width: 280,
    html: '<p><br />MPI Type:<br /><br />选择NASTRAN的可执行文件。\
    <p><br />run Mode:<br /><br />选择是串行执行(serial)、单节点并行(Local)还是跨节点并行(Distributed)\
    </p><p><br />Remote Shell:<br /><br />多节点并行任务，节点之间的访问模式。建议采用默认的SSH模式。\
    </p><p><br />Arguments:<br /><br />CFX的其它选项，默认为空。\
    </p><p><br />Working DIR:<br /><br />本次计算任务的工作目录。\
    </p><p><br />Input File:<br /><br />CFX的输入def文件。\
    </p><p><br />Output File:<br /><br />计算过程中的标准输出和标准错误输出信息，将被重定向保存为文件。</p>\
    <p>&nbsp;</p>',
    title: 'Run Tips',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true,
    collapsible: true,
    collapsed: true
});