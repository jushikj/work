var introTips = new Ext.Panel({
    autoScroll : true,
    width : 280,
    html: '<p><br/>CFX是全球第一个在复杂几何、网格、求解这三个CFD传统瓶径问题上均获得重大突破的商业CFD软件。\
    借助于其独一无二的技术特点，领导着新一代高性能CFD商业软件的整体发展趋势。2003年，CFX加入了全球最大的CAE仿\
    真软件ANSYS的大家庭中。</p><p>&nbsp;</p>',
    title: 'Introduction',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true, 
    collapsible: true, 
    collapsed: false
});



var runTips = new Ext.Panel({
    autoScroll : true,
    width : 280,
    html: '<p><br />MPI Type:<br /><br />选择CFX的可执行文件。\
    <p><br />Grapchic:<br /><br />选择是否启动图形截面的CFX，选择图形截面，则输入参数都要通过图形界面来修改，portal界面上众多元素灰化。\
    </p><p><br />run Mode:<br /><br />选择是串行执行(serial)、单节点并行(Local)还是跨节点并行(Distributed)\
    </p><p><br />Precision:<br /><br />选择单精度(single)或双精度计算(single)，默认为单精度。\
    </p><p><br />Para Method:<br /><br />并行计算时，选择不同的通信方法(PVM,HP MPI,MPICH),建议使用HP MPI。\
    </p><p><br />Remote Shell:<br /><br />多节点并行任务，节点之间的访问模式。建议采用默认的SSH模式。\
    </p><p><br />Arguments:<br /><br />CFX的其它选项，默认为空。\
    </p><p><br />Working DIR:<br /><br />本次计算任务的工作目录。\
    </p><p><br />Input File:<br /><br />CFX的输入def文件。\
    </p><p><br />Output File:<br /><br />计算过程中的标准输出和标准错误输出信息，将被重定向保存为文件。</p>\
    <p>&nbsp;</p>',
    title: 'Run Tips',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true, 
    collapsible: true, 
    collapsed: true
});
