var introTips = new Ext.Panel({
    autoScroll : true,
    width : 280,
    html: '<p><br/>	Dock 是分子对接类最常用,免费的开源软件，使用半柔性对接，即大分子为刚性分子，\
    小分子为柔性分子. Dock支持MPI跨节点并行，并且为任务级并行，跨节点并行效率高，对网络依赖低, \
    详情参阅: http://dock.compbio.ucsf.edu/。</p><p>&nbsp;</p>',
    title: 'Introduction',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true, 
    collapsible: true, 
    collapsed: false
});

var runTips = new Ext.Panel({
    autoScroll : true,
    width : 280,
    html: '<p><br />MPI Type:<br /><br />选择MPI并行环境，如Open MPI或Intel MPI。</p>\
    <p><br />Remote Shell:<br /><br />多节点并行任务，MPI初始化并行环境时，节点之间的访问模式。\
    建议采用默认的SSH模式。</p><p><br />Commucation:<br /><br />多节点并行任务，节点之间数据交换\
    采用何种网络。如果勾选“Share Memory”选项，表示同一节点内的MPI进程采用共享内存方式进行数据交换；\
    如果勾选“CPU Binding”选项，表示将MPI进程与固定的CPU核心绑定，防止进程漂移。\
    开启这两个选项通常可以提高MPI程序的运行速度。\</p><p><br />MPI Program:<br /><br />选择本次计算任务的可执行程序。\
    </p><p><br />Arguments:<br /><br />如果应用程序运行时需要提供自定义的参数，请在此输入。\
    对于VASP软件而言，该选项默认无需设置。</p><p><br />Working DIR:<br /><br />本次计算任务的工作目录。\
    </p><p><br />Input File:<br /><br />应用程序的输入文件。VASP软件的输入文件名默认为INCAR，无需改变。\
    </p><p><br />Output File:<br /><br />计算过程中的标准输出和标准错误输出信息，将被重定向保存为文件。</p>\
    <p>&nbsp;</p>',
    title: 'Run Tips',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true, 
    collapsible: true, 
    collapsed: true
});
