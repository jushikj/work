var introTips = new Ext.Panel({
    autoScroll : true,
    width : 280,
    html: '<p><br/>BLAST是现在应用最广泛的序列比对软件，用于基因、蛋白质序列的两两比对，由NCBI研制。\
    MPIBLAST是NCBI BLAST的并行化实现，基于标准MPI并行环境，可以免费下载使用。</p><p>&nbsp;</p>',
    title: 'Introduction',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true, 
    collapsible: true, 
    collapsed: false
});

var runTips = new Ext.Panel({
    autoScroll : true,
    width : 280,
    html: '<p><br />MPI Type:<br /><br />选择MPI并行环境，如Open MPI或Intel MPI。</p>\
    <p><br />Remote Shell:<br /><br />多节点并行任务，MPI初始化并行环境时，节点之间的访问模式。\
    建议采用默认的SSH模式。</p><p><br />Commucation:<br /><br />多节点并行任务，节点之间数据交换\
    采用何种网络。如果勾选“Share Memory”选项，表示同一节点内的MPI进程采用共享内存方式进行数据交换；\
    如果勾选“CPU Binding”选项，表示将MPI进程与固定的CPU核心绑定，防止进程漂移。\
    开启这两个选项通常可以提高MPI程序的运行速度。\
    </p><p><br />Format DB:<br /><br />选择本次任务是否执行格式化数据库。\
    </p><p><br />DB Program:<br /><br />选择本次计算任务的formatdb可执行程序。\
    </p><p><br />MPI Program:<br /><br />选择本次计算任务的mpiblast可执行程序。\
    </p><p><br />Algorithm:<br /><br />选择本次计算任务的算法，可选blastn, blastp, blastx, tblastn, tblastx。\
    </p><p><br />Arguments:<br /><br />如果应用程序运行时需要提供自定义的参数，请在此输入。\
    </p><p><br />Working DIR:<br /><br />本次计算任务的工作目录。\
    </p><p><br />Local DIR:<br /><br />本次计算任务的临时文件目录，通常选择计算节点本地存储。\
    </p><p><br />Database:<br /><br />本次计算任务的数据库文件。\
    </p><p><br />DB Type:<br /><br />选择数据类型为核酸还是蛋白质。\
    </p><p><br />Input File:<br /><br />选择本次计算任务需要比对的序列文件。\
    </p><p><br />Output File:<br /><br />计算过程中的标准输出和标准错误输出信息，将被重定向保存为文件。</p>\
    <p>&nbsp;</p>',
    title: 'Run Tips',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true, 
    collapsible: true, 
    collapsed: true
});
