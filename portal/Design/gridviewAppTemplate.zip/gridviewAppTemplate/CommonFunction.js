/*!
 * Ext JS Library 3.3.0
 * Copyright(c) 2006-2010 Ext JS, Inc.
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
/**
 * 从/opt/gridview/software/下载指定名称的软件
 *
 * @param {}
 *            softwareName
 */


                  var maxNNodes;
                  var tmpNNodes;
                  var totQueNodes;
                  var maxQueNodes;
                  var maxQueCores;
 var crHome=userhome+"/checkpoints/s_cr";              
 var currentAddr;
    var AddrSplit;
    currentAddr = location.host;
    AddrSplit = currentAddr.split(":");
    currentAddr = AddrSplit[0];    
/*Ext.override(Ext.form.RadioGroup, {
getValue : function() {
        var v;
        this.items.each(function(item) {
            if (item.getValue()) {
                v = item.getId();
              	return false; 
              }
  			});
  			return v;
 },
 setValue : function(v) {
        if (this.rendered) {
            this.items.each(function(item) {
                item.setValue(item.getId() == v);
   });
        } else {
            for (k in this.items) {
                this.items[k].checked = this.items[k].id == v;
            }
        }
 }
});
*/
Ext.override(Ext.form.RadioGroup, {   
    getValue: function(){   
        var v;   
        if (this.rendered) {   
            this.items.each(function(item){   
                if (!item.getValue())    
                    return true;   
                v = item.getId();   
                return false;   
            });   
        }   
        else {   
            for (var k in this.items) {   
                if (this.items[k].checked) {   
                    v = this.items[k].id;   
                    break;   
                }   
            }   
        }   
        return v;   
    },   
    setValue: function(v){   
        if (this.rendered)    
            this.items.each(function(item){   
                item.setValue(item.getId() == v);   
            });   
        else {   
            for (var k in this.items) {   
                this.items[k].checked = this.items[k].id == v;   
            }   
        }   
    }   
});  



Ext.override(Ext.form.Checkbox, {
    getValue : function() {
        var v;
        if ( this.disabled == true ) {
        	v="null";}
        	else if (this.checked == true) {
        		v="1";
        		} else
        			{v="0";}
                return v;
 
  }
});                     
                  /**
 * 浏览器判定使用
 *
 * @type
 */
window["MzBrowser"] = {};
(function() {
  if (MzBrowser.platform)
    return;
  var ua = window.navigator.userAgent;
  MzBrowser.platform = window.navigator.platform;

  MzBrowser.firefox = ua.indexOf("Firefox") > 0;
  MzBrowser.opera = typeof (window.opera) == "object";
  MzBrowser.ie = !MzBrowser.opera && ua.indexOf("MSIE") > 0;
  MzBrowser.mozilla = window.navigator.product == "Gecko";
  MzBrowser.netscape = window.navigator.vendor == "Netscape";
  MzBrowser.safari = ua.indexOf("Safari") > -1;

  if (MzBrowser.firefox)
    var re = /Firefox(\s|\/)(\d+(\.\d+)?)/;
  else if (MzBrowser.ie)
    var re = /MSIE( )(\d+(\.\d+)?)/;
  else if (MzBrowser.opera)
    var re = /Opera(\s|\/)(\d+(\.\d+)?)/;
  else if (MzBrowser.netscape)
    var re = /Netscape(\s|\/)(\d+(\.\d+)?)/;
  else if (MzBrowser.safari)
    var re = /Version(\/)(\d+(\.\d+)?)/;
  else if (MzBrowser.mozilla)
    var re = /rv(\:)(\d+(\.\d+)?)/;

  if ("undefined" != typeof (re) && re.test(ua))
    MzBrowser.version = parseFloat(RegExp.$2);
})();

function coreSoftwareDownload(softwareName) {

  var softwareWebRoot = "/commonsoft/";
  var rePath = "";

  Ext.Ajax.request({
    url : softwareWebRoot + "softwaremanagement/softwareDownload.action",
    callback : function(options, success, response) {
      if (Ext.decode(response.responseText)['success'] == true)
      {
        var softwareUrl = Ext.decode(response.responseText)["path"];
        window.open(softwareWebRoot + softwareUrl);
        } else {
          Ext.MessageBox.show({
            title : gvI18n('错误'),
            msg : gvI18n("您要下载的软件不存在"),
            buttons : Ext.MessageBox.OK,
            icon : Ext.MessageBox.ERROR
            });
          }
      },
    params : {
        softwareName : softwareName
        },
    scope : this
    });

  return rePath;

}

/****************************WinSCP*******************************************/

/*
 * Gridview ParameterView 模块
 */

// Ext.namespace('gridview.core.pageintegration.webapp.commonsoftwaremanagement');
/**
 * 支持winscp、putty的启动
 *
 * @param softwareName,
 *            ipPath, initPath ipPath:访问IP地址 initPath：访问起始目录
 *            如："/opt/gridview/"
 * @return
 */
function coreSoftwareOpen(softwareName, ipPath, initPath) {

  // 1.获取用户信息
  var osUser = portal_strOsUser;
  var gvUser = portal_strGvUser;
  var userMode = portal_strUserMode;
  var userPasswd = portal_strUserPasswd;
  initPath = initPath + "/";

  // 2.操作系统判定,只支持Windows操作系统
  var isWin = (navigator.platform == "Win32") || (navigator.platform == "Windows");

  if (!isWin) {
    Ext.MessageBox.show( {
      title : gvI18n("winscp_error"),
      msg : gvI18n("winscp_ossupport"),
      buttons : Ext.MessageBox.OK,
      icon : Ext.MessageBox.ERROR
    });
    return;
  }

  try {
    // 3.获取登录节点IP
    var sip = ipPath;
    var cmd = "";
    var arg = "";
    // 4判断浏览器类型IE
    if (MzBrowser.ie) {
      // 4.1 用户类型判定
      if (userMode == 'systemUser') {
        // 4.1.1判断软件类型
        if (softwareName == "winscp") {
          cmd = "winscp.exe sftp://" + osUser + ":"
              + userPasswd + "@" + sip + initPath;
        } else if (softwareName == "putty") {
          cmd = "putty.exe " + osUser + "@" + sip + " -pw "
              + userPasswd;
        }
      } else {
        if (softwareName == "winscp") {
          cmd = "winscp.exe sftp://" + osUser + "@" + sip
              + initPath;
        } else if (softwareName == "putty") {
          cmd = "putty.exe " + osUser + "@" + sip;
        }
      }

      // 4.2 启动Winscp
      var tmpObj = new ActiveXObject("wscript.shell").run(cmd);
    }

    // 4判断浏览器类型FF
    if (MzBrowser.firefox) {
      // 软件判断
      var cmd64 = "";

      if (softwareName == "winscp") {
        cmd = "C:\\Program\ Files\\Sugon\ WinSCP&Putty\\WinSCP.exe";
        cmd64 = "C:\\Program\ Files\ (x86)\\Sugon\ WinSCP&Putty\\WinSCP.exe";
      } else if (softwareName == "putty") {
        cmd = "C:\\Program\ Files\\Sugon\ WinSCP&Putty\\putty.exe";
        cmd64 = "C:\\Program\ Files\ (x86)\\Sugon\ WinSCP&Putty\\putty.exe";
      }
      // 4.1 用户类型判定
      var arguments = [ arg ];

      if (userMode == 'systemUser') {
        // 软件判断
        if (softwareName == "winscp") {
          arg = "sftp://" + osUser + ":" + userPasswd + "@"
              + sip + initPath;
          arguments = [ arg ];

        } else if (softwareName == "putty") {
          var arg0 = osUser + "@" + sip;
          var arg1 = "-pw";
          var arg2 = userPasswd;
          arguments = [ arg0, arg1, arg2 ];
        }
      } else {
        // 软件判断
        if (softwareName == "winscp") {
          arg = "sftp://" + osUser + "@" + sip + initPath;
        } else if (softwareName == "putty") {
          arg = osUser + "@" + sip;
        }
        arguments = [ arg ];
      }

      // 4.2 启动Winscp
      netscape.security.PrivilegeManager
          .enablePrivilege("UniversalXPConnect");
      var process = Components.classes['@mozilla.org/process/util;1']
          .createInstance(Components.interfaces.nsIProcess);
      var file = Components.classes['@mozilla.org/file/local;1']
          .createInstance(Components.interfaces.nsILocalFile);
      try {
        file.initWithPath(cmd);
        process.init(file);
        process.run(false, arguments, arguments.length, {});
      } catch (e) {
        // 64位系统判定
        file.initWithPath(cmd64);
        process.init(file);
        process.run(false, arguments, arguments.length, {});
      }
    }
  } catch (e) {
    // 5 启动失败提示
    var linkcannotopen = "";
    if (softwareName == "winscp") {
      var linkcannotopen = gvI18n("无法启动WinSCP，请确定以下操作是否均已完成：");
    } else if (softwareName == "putty") {
      var linkcannotopen = gvI18n("putty_cannotopen");
    }
    var linkdownloadconf = gvI18n("请下载并安装WinSCP程序。")
        + "<a href=\"#\" onclick=\"coreSoftwareDownload('winscp_puttysetup.exe');\">"
        + gvI18n("点击下载WinSCP") + "</a>";
    if (MzBrowser.ie) {
      // ie设置提示
      var winscpieset = gvI18n("安全设置中“ActiveX空间和插件”的“对未标记为可安全执行的脚本的ActiveX控件初始化并执行脚本”项已改为“启用”");
      Ext.MessageBox.show( {
        title : gvI18n("提示"),
        msg : linkcannotopen + "<br/><br/>1." + winscpieset
            + "<br/><br/>2." + linkdownloadconf,
        buttons : Ext.MessageBox.OK,
        icon : Ext.MessageBox.INFO
      });
    }
    if (MzBrowser.firefox) {
      // ff设置提示
      var winscpffset = gvI18n("请在浏览器地址栏输入“about:config”并回车，将[signed.applets.codebase_principal_support]设置为true");
      Ext.MessageBox.show( {
        title : gvI18n("提示"),
        msg : linkcannotopen + "<br/><br/>1." + winscpffset
            + "<br/><br/>2." + linkdownloadconf,
        buttons : Ext.MessageBox.OK,
        icon : Ext.MessageBox.INFO
      });
    }
  }

}





/*** ********************************openPath函数*************************************/

            function openPathRelative(par_textid,par_initPath) {
            	  var currentnode;
                var currentfile;
                var showpath;
                var upPath;
                var pathsplit;
                var upfilePath;
                var filepathsplit;
                var pathUp_mark = 0;

              if (document.getElementById("pathwin") == null) {
                window1.innerHTML = "";

                var id1 = par_initPath;
                currentnode = par_initPath;
                showpath = currentnode;
                var pathtreeloader = new Ext.tree.TreeLoader(
                    {
                      url : "/jm_as/appsubmit/listUserDirectory.action"
                    });

                pathtreeloader.on('beforeload',function(ld, node) {
                  // 如果为work path的值为HOME
                  if (currentnode == "HOME")
                    currentnode = userhome;
                  else if (pathUp_mark != 1)
                    currentnode = node.id;

                  pathUp_mark = 0;

                  ld.baseParams = {
                    strDirPath : currentnode,
                    strJobManagerID : portal_strJobManagerID,
                    strJobManagerAddr : portal_strJobManagerAddr,
                    strJobManagerPort : portal_strJobManagerPort,
                    strJobManagerType : portal_strJobManagerType
                    };
                  })

                var pathtree = new Ext.tree.TreePanel({
                  root : new Ext.tree.AsyncTreeNode({text : showpath,id : id1}),
                  autoScroll : true,
                  loader : pathtreeloader
                });

                new Ext.tree.TreeSorter(pathtree, {folderSort:true});

                var win = new Ext.Window(
                    {
                      renderTo : 'window1',
                      title : "选择路径",
                      id : "pathwin",
                      width : 200,
                      height : 375,
                      layout : 'fit',
                      closable : true,
                      draggable : true,
                      resizable : false,
                      buttons : [{
                        text : "确定",// iconCls:"browser",
                        width : 50,
                        handler : function() {
                          if (currentnode == "0" || leaf_node == true)
                            Ext.MessageBox.alert('提示','请选择路径',"");
                          else
                          {
                            currentnode=relativeFileName(currentnode);
                            Ext.getCmp(par_textid).setValue(currentnode);
                            win.close();
                          }
                        }
                      },{
                        text : "关闭",// iconCls:"delete",
                        width : 50,
                        handler : function(){win.close()}
                      },{
                        text : "上级目录",
                        width : 50,// iconCls:"delete",
                        handler : function() {
                          pathsplit = currentnode.split("/");

                          upPath = "";
                          var num = 1;
                          while (pathsplit[num + 1] != null)
                            num++;
                          if (pathsplit[2] != null)
                          {
                            for (i = 1; i < num; i++)
                              upPath = upPath + '/' + pathsplit[i];
                          } else upPath = "/";

                          currentnode = upPath;
                          pathUp_mark = 1;
                          pathtree.root.reload();
                          pathtree.root.setText(upPath);
                        }
                      }],
                      items : pathtree
                    });

                var leaf_node = "0";
                win.setPosition(875, 340);
                win.show();

                pathtree.on("click", function(node) {
                  currentnode = node.id;
                  leaf_node = node.leaf;
                  });
                }  	else 
                	{alert("File Tree has been open!!");}

              }
              function openPath(par_textid,par_initPath) {
            	  var currentnode;
                var currentfile;
                var showpath;
                var upPath;
                var pathsplit;
                var upfilePath;
                var filepathsplit;
                var pathUp_mark = 0;

              if (document.getElementById("pathwin") == null) {
                window1.innerHTML = "";

                var id1 = par_initPath;
                currentnode = par_initPath;
                showpath = currentnode;
                var pathtreeloader = new Ext.tree.TreeLoader(
                    {
                      url : "/jm_as/appsubmit/listUserDirectory.action"
                    });

                pathtreeloader.on('beforeload',function(ld, node) {
                  // 如果为work path的值为HOME
                  if (currentnode == "HOME")
                    currentnode = userhome;
                  else if (pathUp_mark != 1)
                    currentnode = node.id;

                  pathUp_mark = 0;

                  ld.baseParams = {
                    strDirPath : currentnode,
                    strJobManagerID : portal_strJobManagerID,
                    strJobManagerAddr : portal_strJobManagerAddr,
                    strJobManagerPort : portal_strJobManagerPort,
                    strJobManagerType : portal_strJobManagerType
                    };
                  })

                var pathtree = new Ext.tree.TreePanel({
                  root : new Ext.tree.AsyncTreeNode({text : showpath,id : id1}),
                  autoScroll : true,
                  loader : pathtreeloader
                });

                new Ext.tree.TreeSorter(pathtree, {folderSort:true});

                var win = new Ext.Window(
                    {
                      renderTo : 'window1',
                      title : "选择路径",
                      id : "pathwin",
                      width : 200,
                      height : 375,
                      layout : 'fit',
                      closable : true,
                      draggable : true,
                      resizable : false,
                      buttons : [{
                        text : "确定",// iconCls:"browser",
                        width : 50,
                        handler : function() {
                          if (currentnode == "0" || leaf_node == true)
                            Ext.MessageBox.alert('提示','请选择路径',"");
                          else
                          {
                            Ext.getCmp(par_textid).setValue(currentnode);
                            win.close();
                          }
                        }
                      },{
                        text : "关闭",// iconCls:"delete",
                        width : 50,
                        handler : function(){win.close()}
                      },{
                        text : "上级目录",
                        width : 50,// iconCls:"delete",
                        handler : function() {
                          pathsplit = currentnode.split("/");

                          upPath = "";
                          var num = 1;
                          while (pathsplit[num + 1] != null)
                            num++;
                          if (pathsplit[2] != null)
                          {
                            for (i = 1; i < num; i++)
                              upPath = upPath + '/' + pathsplit[i];
                          } else upPath = "/";

                          currentnode = upPath;
                          pathUp_mark = 1;
                          pathtree.root.reload();
                          pathtree.root.setText(upPath);
                        }
                      }],
                      items : pathtree
                    });

                var leaf_node = "0";
                win.setPosition(875, 340);
                win.show();

                pathtree.on("click", function(node) {
                  currentnode = node.id;
                  leaf_node = node.leaf;
                  });
                }  	else 
                	{alert("File Tree has been open!!");}

              }
/**************************fileDir*******************************************/              
            function relativeFileName(par_filename) {
                var filepathsplit;
                var tmpFileName;
alert(par_filename)
                if (par_filename.charAt(0) == '/')
                {

                  filepathsplit = par_filename.split("/");
                  upfilePath = "";
                  var num = 0;
                  while (filepathsplit[num + 1] != null)
                    num++;
                   tmpFileName=filepathsplit[num];    
                } else
                tmpFileName=par_filename;
            	    return tmpFileName;
            }
            function fileDir(par_filename) {
                var filepathsplit;
                var upfilePath;
                if (par_filename.charAt(0) == '/')
                {

                  filepathsplit = par_filename.split("/");
                  upfilePath = "";
                  var num = 1;
                  while (filepathsplit[num + 1] != null)
                    num++;

                  if (filepathsplit[2] != null)
                  {
                    for (i = 1; i < num; i++)
                      upfilePath = upfilePath+ '/' + filepathsplit[i];
                  } else
                    upfilePath = "/";
                } else
                alert("you should absolute path of file");
            	    return upfilePath;
            	}
            	
/**************************openFile*******************************************/
            function openFileRelative(par_textid,par_initPath) {
            	  var currentnode;
                var currentfile;
                var showpath;
                var upPath;
                var pathsplit;
                var upfilePath;
                var filepathsplit;
                var fileUp_mark = 0;
                
                
                
              if (document.getElementById("filewin") == null)
              {
                window2.innerHTML = "";

                var id2 = par_initPath;
                currentfile = par_initPath;
               
                var filetreeloader = new Ext.tree.TreeLoader({
                  url : "/jm_as/appsubmit/listUserDirectory.action"
                    });

                filetreeloader.on('beforeload',function(ld, node) {
                  if (fileUp_mark == 0)
                    currentfile = node.id;

                  fileUp_mark = 0;

                  ld.baseParams = {
                      strDirPath : currentfile,
                      strJobManagerID : portal_strJobManagerID,
                      strJobManagerAddr : portal_strJobManagerAddr,
                      strJobManagerPort : portal_strJobManagerPort,
                      strJobManagerType : portal_strJobManagerType
                      };
                  })

                var filetree = new Ext.tree.TreePanel({
                  root : new Ext.tree.AsyncTreeNode( {text : currentfile,id : id2}),
                  autoScroll : true,
                  loader : filetreeloader
                  });

                new Ext.tree.TreeSorter(filetree, {folderSort:true});

                var win = new Ext.Window({
                  renderTo : 'window2',
                  title : "选择文件",
                  id : "filewin",
                  width : 200,
                  height : 375,
                  layout : 'fit',
                  closable : true,
                  draggable : true,
                  resizable : false,
                  buttons : [{
                    text : "确定",// iconCls:"browser",
                    width : 50,
                    handler : function() {
                      if (leaf_node1 == false)
                        Ext.MessageBox.alert('提示','请选择文件',"");
                      else
                      {
                        currentfile=relativeFileName(currentfile);
                        Ext.getCmp(par_textid).setValue(currentfile);
                        //jobScriptRefresh();
                        win.close();
                      }
                    }
                  },{
                    text : "关闭",
                    width : 50,// iconCls:"delete",
                    handler : function() {win.close()}
                  },{
                    text : "上级目录",
                    width : 50,// iconCls:"delete",
                    handler : function() {
                      filepathsplit = currentfile.split("/");
                      upfilePath = "";
                      var num = 1;
                      while (filepathsplit[num + 1] != null)
                        num++;

                      if (filepathsplit[2] != null)
                      {
                        for (i = 1; i < num; i++)
                          upfilePath = upfilePath+ '/' + filepathsplit[i];
                      } else
                        upfilePath = "/";
                      currentfile = upfilePath;
                      fileUp_mark = 1;
                      filetree.root.reload();
                      filetree.root.setText(upfilePath);
                      }
                  }],
                  items : filetree
                });

                var leaf_node1 = "0";
                win.setPosition(875, 340);
                win.show();

                filetree.on("click", function(node) {
                  currentfile = node.id;
                  leaf_node1 = node.leaf;
                  });
                }
                else
                	{alert("File Tree has been open!!");}
              }
                         function openFile(par_textid,par_initPath) {
            	  var currentnode;
                var currentfile;
                var showpath;
                var upPath;
                var pathsplit;
                var upfilePath;
                var filepathsplit;
                var fileUp_mark = 0;
                
                
                
              if (document.getElementById("filewin") == null)
              {
                window2.innerHTML = "";

                var id2 = par_initPath;
                currentfile = par_initPath;
               
                var filetreeloader = new Ext.tree.TreeLoader({
                  url : "/jm_as/appsubmit/listUserDirectory.action"
                    });

                filetreeloader.on('beforeload',function(ld, node) {
                  if (fileUp_mark == 0)
                    currentfile = node.id;

                  fileUp_mark = 0;

                  ld.baseParams = {
                      strDirPath : currentfile,
                      strJobManagerID : portal_strJobManagerID,
                      strJobManagerAddr : portal_strJobManagerAddr,
                      strJobManagerPort : portal_strJobManagerPort,
                      strJobManagerType : portal_strJobManagerType
                      };
                  })

                var filetree = new Ext.tree.TreePanel({
                  root : new Ext.tree.AsyncTreeNode( {text : currentfile,id : id2}),
                  autoScroll : true,
                  loader : filetreeloader
                  });

                new Ext.tree.TreeSorter(filetree, {folderSort:true});

                var win = new Ext.Window({
                  renderTo : 'window2',
                  title : "选择文件",
                  id : "filewin",
                  width : 200,
                  height : 375,
                  layout : 'fit',
                  closable : true,
                  draggable : true,
                  resizable : false,
                  buttons : [{
                    text : "确定",// iconCls:"browser",
                    width : 50,
                    handler : function() {
                      if (leaf_node1 == false)
                        Ext.MessageBox.alert('提示','请选择文件',"");
                      else
                      {
                        Ext.getCmp(par_textid).setValue(currentfile);
                        //jobScriptRefresh();
                        win.close();
                      }
                    }
                  },{
                    text : "关闭",
                    width : 50,// iconCls:"delete",
                    handler : function() {win.close()}
                  },{
                    text : "上级目录",
                    width : 50,// iconCls:"delete",
                    handler : function() {
                      filepathsplit = currentfile.split("/");
                      upfilePath = "";
                      var num = 1;
                      while (filepathsplit[num + 1] != null)
                        num++;

                      if (filepathsplit[2] != null)
                      {
                        for (i = 1; i < num; i++)
                          upfilePath = upfilePath+ '/' + filepathsplit[i];
                      } else
                        upfilePath = "/";
                      currentfile = upfilePath;
                      fileUp_mark = 1;
                      filetree.root.reload();
                      filetree.root.setText(upfilePath);
                      }
                  }],
                  items : filetree
                });

                var leaf_node1 = "0";
                win.setPosition(875, 340);
                win.show();

                filetree.on("click", function(node) {
                  currentfile = node.id;
                  leaf_node1 = node.leaf;
                  });
                }
                else
                	{alert("File Tree has been open!!");}
              }

/**************************SetFunction*******************************************/      
            function setJobSch(par_nnodes,par_ppn,par_hour,par_minute,par_second,par_queue,par_name) {
            Ext.getCmp("nnodes").setValue(par_nnodes);
            Ext.getCmp("ppn").setValue(par_ppn);
            Ext.getCmp("hours").setValue(par_hour);
            Ext.getCmp("minutes").setValue(par_minute);
            Ext.getCmp("seconds").setValue(par_second);
            Ext.getCmp("queue").setValue(par_queue);
            Ext.getCmp("name").setValue(par_name);
            }
            function setNetwork(par_ib_avi,par_network)  {
            if (par_ib_avi == "1")
            {
               Ext.getCmp("ib").enable();
            	 if (par_network == "ib")
                {
                Ext.getDom("ib").checked = true;
                Ext.getDom("tcp").checked = false;
               }
               else
               {
                 Ext.getDom("tcp").checked = true;
                 Ext.getDom("ib").checked = false;
               }
            }
            else
            {            
            	Ext.getCmp("ib").disable();
              Ext.getDom("tcp").checked = true;
              Ext.getDom("ib").checked = false;
            	 }
       }
  function setRemoteSh(par_RemoteSh) {
  	         if (par_RemoteSh == "ssh")
            {Ext.getDom("ssh").checked = true;}
            else
            Ext.getDom("rsh").checked = true;
  }
  function setRunCommon(par_program,par_workdir,par_output) {
	          Ext.getCmp("program").setValue(par_program);              
            Ext.getCmp("workdir").setValue(par_workdir);
            Ext.getCmp("output").setValue(par_output);
	}
  function setCR(par_cr_avi,par_cr,par_interval) {
	               if (par_cr_avi == '0' )
               {
                 Ext.getCmp("checkpoint").disable();
                 Ext.getCmp("checkpoint").setValue(false);
                 checkpoint = '0';
                 Ext.getCmp("interval").disable();
                 Ext.getCmp("interval").setValue("");
               }
               else if ( par_cr == '0' )
               {
                 Ext.getCmp("checkpoint").enable();
                 Ext.getCmp("checkpoint").setValue(false);
                 checkpoint = '0';
                 Ext.getCmp("interval").disable();
                Ext.getCmp("interval").setValue(par_interval);
               }
               else
               {
               	Ext.getCmp("checkpoint").enable();
                Ext.getCmp("checkpoint").setValue(true);
                checkpoint = '1';
                Ext.getCmp("interval").enable();
                Ext.getCmp("interval").setValue(par_interval);
               	}
	}
	function setCRVisual(par_cr_avi,par_cr,par_interval) {
	               if (par_cr_avi == '0' )
               {
                 Ext.getCmp("CRField").setVisible(false);
                 Ext.getCmp("checkpoint").disable();
                 Ext.getCmp("checkpoint").setValue(false);
                 checkpoint = '0';
                 Ext.getCmp("interval").disable();
                 Ext.getCmp("interval").setValue("");
               }
               else if ( par_cr == '0' )
               {
               	Ext.getCmp("CRField").setVisible(true);
                 Ext.getCmp("checkpoint").enable();
                 Ext.getCmp("checkpoint").setValue(false);
                 checkpoint = '0';
                 Ext.getCmp("interval").disable();
                Ext.getCmp("interval").setValue(par_interval);
               }
               else
               {
               	Ext.getCmp("CRField").setVisible(true);
               	Ext.getCmp("checkpoint").enable();
                Ext.getCmp("checkpoint").setValue(true);
                checkpoint = '1';
                Ext.getCmp("interval").enable();
                Ext.getCmp("interval").setValue(par_interval);
               	}
	}
  function setVnc(par_vnc_avi,par_vnc) {
	               if (par_vnc_avi == '1' )
               { 
               	Ext.getCmp("IsVNC").enable(); 
               	Ext.getCmp("vncField").setVisible(true);}
               else
               { Ext.getCmp("IsVNC").disable();
               	Ext.getCmp("vncField").setVisible(false); }
               if (par_vnc == '1')
               { Ext.getCmp("IsVNC").setValue(true); 
               	}
               else
               { Ext.getCmp("IsVNC").setValue(false); 
               	}
	}
  function setAdv1(par_mpi_opt,par_pbs_opt,par_pre_cmd,par_post_cmd) {
	             Ext.getCmp("mpiAdvOpt").setValue(par_mpi_opt);
               Ext.getCmp("pbsAdvOpt").setValue(par_pbs_opt);
               Ext.getCmp("preCommands").setValue(par_pre_cmd);
               Ext.getCmp("postCommands").setValue(par_post_cmd);  
	}
  function setAdv2(par_pbs_opt,par_pre_cmd,par_post_cmd) {
	               Ext.getCmp("pbsAdvOpt2").setValue(par_pbs_opt);
               Ext.getCmp("preCommands2").setValue(par_pre_cmd);
               Ext.getCmp("postCommands2").setValue(par_post_cmd);  
	}
  
 /****** Refresh Function ****/ 
  
  function cquotaBarRefresh() {
         totCPUTime = Ext.getCmp("nnodes").getValue() * Ext.getCmp("ppn").getValue() * Ext.getCmp("hours").getValue();
         cqBarProgres =  totCPUTime / dUserCqHour;
         if (cqBarProgres >1) cqBarProgres=1.0;
         Ext.getCmp("cquotaBar").updateProgress(cqBarProgres);
    }
    
	function mpiRelateRefresh() {
    	var network_status;
    	var checkpoint_status;
    	if (( ib_available == '1' ) && (Ext.getCmp("ib").getValue() == true))
    	network_status='ib';
    	else
    	network_status='tcp';
    	if (( checkpoint_available == '1' ) && (Ext.getCmp("checkpoint").getValue() == true))
    	checkpoint_status='1';
    	
    	if (Ext.getCmp("mpitype").getValue() == 'mpich2') {
    		setNetwork(0,'tcp');
    		setCR('0','0','interval');
    		} else if (Ext.getCmp("mpitype").getValue() == 'cr_mpi') {
    			setNetwork(ib_available,network_status);
    			setCR(checkpoint_available,checkpoint,interval);
    			} else {
    			setNetwork(ib_available,network_status);
    			setCR('0','0','interval');
    			}

    }
       
	function queueRelateRefresh() {

    	  for( j=0; j< aQueStat.length; j++)
        {
        	if (Ext.getCmp("queue").getValue() == aQueStat[j][1])
        	{
        	  Ext.getCmp("ppn").setMaxValue(aQueStat[j][8]);
        	  Ext.getCmp("ppn").setValue(aQueStat[j][8]);

        	  if (aQueStat[j][13] != 'unlimit') //min nodes allowed
        	  {
        	  	Ext.getCmp("nnodes").setMinValue(aQueStat[j][13]);
        	  }

        	  totQueNodes=aQueStat[j][2];       //total nodes in queue
        	  maxNNodes=aQueStat[j][2];

        	  maxQueNodes=aQueStat[j][10];      //max nodes allowed
        	  if (aQueStat[j][10] != 'unlimit')
        	  {
        	  	tmpNNodes=aQueStat[j][10];
        	  	if (maxNNodes > tmpNNodes) maxNNodes=tmpNNodes;
        	  }

        	  maxQueCores=aQueStat[j][11];        //max cores allowed
        	  if (aQueStat[j][11] != 'unlimit')
        	  {
        	    tmpNNodes=aQueStat[j][11] / aQueStat[j][8];
        	    if (maxNNodes > tmpNNodes) maxNNodes=tmpNNodes;
        	  }

        	  Ext.getCmp("nnodes").setMaxValue(maxNNodes);
        	  if(Ext.getCmp("nnodes").getValue() > maxNNodes) Ext.getCmp("nnodes").setValue(maxNNodes);

        	  break;
          }
        }

    }

 
/**** Get  Function   *****/

	function getNetwork() {
		             var gap_network;
		              if (Ext.getCmp("ib").getValue() == true)
	                gap_network = 'ib';
	              else if  (Ext.getCmp("tcp").getValue() == true)
	                gap_network = 'tcp';
	                return gap_network;
		}
	function getRemoteSh() {
		var gap_remote_sh;
	              if (Ext.getCmp("rsh").getValue() == true)
	                gap_remote_sh = 'rsh';
	              else
	                gap_remote_sh = 'ssh';
	                return gap_remote_sh;
	
		}
	function getCpuBind() {
		var gap_cpu_binding;
	              if ((Ext.getCmp("cpuBind").getValue() == true))
	                gap_cpu_binding = '1';
	              else
	                gap_cpu_binding = null;
	                return gap_cpu_binding;
		}
	function getShareMem() {
		              var gap_share_mem;
		              if (Ext.getCmp("memory").getValue() == true)
	                gap_share_mem = '1';
	              else
	              	gap_share_mem = null;
	              	return gap_share_mem;
		}
	function getCR() {
		              var gap_checkpoint;
		              if ( checkpoint_available == '1') {
		                if (Ext.getCmp("checkpoint").getValue() == true)
	                   gap_checkpoint = '1';
	                   else
	                   gap_checkpoint = null;
	              } else
	              	{gap_checkpoint = null;}
	              	return gap_checkpoint;
	              	
		}
	function getInterval() {
	              var gap_interval;
	              if (( checkpoint_available == '1') && (Ext.getCmp("checkpoint").getValue() == true))
	                gap_interval = Ext.getCmp("interval").getValue();
	              else
	                gap_interval = null;
	                return  gap_interval;
		}
	function getVnc() {
		var gap_vnc;
	      if ((Ext.getCmp("IsVNC").getValue() == true))
	                gap_vnc = '1';
	              else
	              	gap_vnc = null;
	              	return gap_vnc;
		}




