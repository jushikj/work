var introTips = new Ext.Panel({
    autoScroll: true,
    width: 280,
    html: '<p><br/>serial and openmp Portal是Gridview Clusportal最基本的portal，可以支持串行程序和openmp程序的\
    作业提交运行，并支持vnc的图形作业，以及clusnap的自动checkpoint功能，此portal适用串行程序和openmp程序，估支持的\
    节点数只能为1。</p><p>&nbsp;</p>',
    title: 'Introduction',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true,
    collapsible: true,
    collapsed: false
});



var runTips = new Ext.Panel({
    autoScroll: true,
    width: 280,
    html: '<p><br />MPI Type:<br /><br /><br />选择本次计算任务的可执行程序。</p>\
    <p><br />Arguments:<br /><br />如果应用程序运行时需要提供自定义的参数，请在此输入。</p>\
    <p><br />Working DIR:<br /><br />本次计算任务的工作目录。</p>\
    <p><br />Output File:<br /><br />计算过程中的标准输出和标准错误输出信息，将被重定向保存为文件。\
    <p>&nbsp;</p>',
    title: 'Run Tips',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true,
    collapsible: true,
    collapsed: true
});