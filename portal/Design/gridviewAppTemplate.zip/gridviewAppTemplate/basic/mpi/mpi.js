Ext.onReady(function() {

    // turn on validation errors beside the field globally


    // coreSoftwareOpen("winscp", 集群管理节点ip, UserHomePath)

    var currentAddr;
    var AddrSplit;
    currentAddr = location.host;
    AddrSplit = currentAddr.split(":");
    currentAddr = AddrSplit[0];

    /*********************Run Parameter*************************************/

    var RunField = new Ext.form.FieldSet({
        title: "Run Parameters",
        /*******************************Run Parameter*************************************/
        layout: "form",
        xtype: 'fieldset',
        autoWidth: true,
        hideCollapseTool: false,
        titleCollapse: true,
        collapsible: true,
        labelWidth: 80,
        items: [{
                layout: "column",
                width: 450,
                autoWidth: true,
                items: [{
                        layout: "form",
                        columnWidth: .5,
                        labelWidth: 80,
                        items: [{
                                fieldLabel: 'MPI Type',
                                id: 'mpitype',
                                xtype: 'combo',
                                mode: 'local',
                                width: 180,
                                value: mpitype,
                                triggerAction: 'all',
                                forceSelection: true,
                                editable: false,
                                name: 'mpitype',
                                displayField: 'MPI',
                                valueField: 'MPI',
                                store: s_mpi
                            }

                        ]
                    }, {
                        layout: "form",
                        columnWidth: .5,

                        items: [{
                                fieldLabel: 'Remote Shell',
                                xtype: 'radiogroup',
                                id: "remoteShell",
                                items: [{
                                        boxLabel: 'RSH',
                                        name: 'sh',
                                        id: 'rsh',
                                        inputValue: 'RSH'
                                    }, {
                                        boxLabel: 'SSH',
                                        name: 'sh',
                                        id: 'ssh',
                                        inputValue: 'SSH',
                                        checked: true
                                    }
                                ]
                            }

                        ]
                    }
                ]
            }, {
                layout: 'column',
                items: [{
                        layout: 'form',
                        columnWidth: .35,
                        items: [{
                                fieldLabel: 'Commucation',
                                xtype: 'radiogroup',
                                id: 'commucation',
                                width: 145,
                                items: [{
                                        boxLabel: 'TCP',
                                        name: 'network',
                                        id: 'tcp',
                                        inputValue: 'tcp'
                                    }, {
                                        boxLabel: 'Infiniband',
                                        name: 'network',
                                        id: 'ib',
                                        inputValue: 'ib',
                                        checked: true
                                    }
                                ]
                            }
                        ]
                    }, {
                        xtype: 'checkbox',
                        columnWidth: .15,
                        id: 'memory',
                        name: 'shareMem',
                        boxLabel: 'Share Memory',
                        inputValue: 'memory',
                        checked: true
                    }, {
                        layout: 'form',
                        columnWidth: .2,
                        items: [{
                                xtype: 'checkboxgroup',
                                fieldLabel: 'CPU Binding',
                                id: 'mpiSmBind',
                                name: 'mpiSmBind',
                                items: [{
                                        xtype: 'checkbox',
                                        id: 'cpuBind',
                                        name: 'cpuBind',
                                        boxLabel: 'Yes',
                                        inputValue: 'cpuBind',
                                        checked: true
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }, {
                layout: 'column',
                items: [{
                        layout: 'form',
                        columnWidth: .6,
                        items: [{
                                fieldLabel: 'MPI Program',
                                xtype: 'combo',
                                width: 340,
                                mode: 'local',
                                id: 'program',
                                value: program,
                                triggerAction: 'all',
                                forceSelection: false,
                                editable: true,
                                name: 'program',
                                displayField: 'MPIPROG',
                                valueField: 'MPIPROG',
                                store: s_prog
                            }
                        ]
                    }, {
                        xtype: 'button',
                        columnWidth: .1,
                        text: "Browse...",
                        handler: function() {
                            file = Ext.getCmp("program").getValue();
                            var filePath = fileDir(file);
                            openFile("program", filePath);
                        }
                    }
                ]
            }, {
                fieldLabel: 'Arguments',
                width: 340,
                xtype: 'textfield',
                name: 'programarg',
                id: "programarg",
                allowBlank: true
            }, {
                layout: 'column',
                items: [{
                        layout: 'form',
                        columnWidth: .6,
                        items: [{
                                fieldLabel: 'Working DIR',
                                width: 340,
                                xtype: 'textfield',
                                name: 'workdir',
                                id: "workdir",
                                allowBlank: false
                            }
                        ]
                    }, {
                        columnWidth: .1,
                        xtype: 'button',
                        text: "Browse...",
                        id: "PathBtn",
                        handler: function() {
                            var filePath = Ext.getCmp("workdir").getValue();
                            openPath("workdir", filePath);
                        }
                    }
                ]
            }, {
                fieldLabel: 'Output File',
                xtype: 'textfield',
                width: 340,
                name: 'output',
                id: "output",
                allowBlank: false
            }
        ]
    });
    var simple = new Ext.FormPanel({
        labelAlign: 'left',
        frame: true,
        title: portal_strAppName + " Portal v" + portal_version,
        layout: "form",
        id: "simple",
        bodyStyle: 'padding:5px 5px 0',
        width: 800,
        buttonAlign: "center",
        items: [{
                xtype: 'panel',
                border: false,
                html: '<p align="center"><img src="' + imgName + '"/></p>'
            },
            AviResField,
            JobSchField,
            RunField,
            VncField,
            CRField,
            AdvField1
        ],

        buttons: [{
                text: 'Submit',
                id: 'submit',
                handler: mySubmit
            }, {
                text: 'Reset',
                id: 'resetting',
                // iconCls:'freshbutton',
                handler: function() {
                    simple.getForm().reset();
                    formAllReset();
                }
            }
        ]
    });


    var tmpPanel = new Ext.Panel({
        renderTo: Ext.getBody(),
        autoScroll: true,
        layout: "column",
        width: 1150,
        bodyStyle: 'padding-left:15px;padding-bottom:30px',
        frame: true,
        items: [{
                layout: "form",
                columnWidth: .73,
                items: [simple]
            }, {
                layout: "form",
                items: [introTips, resTips, jobTips, runTips, vncTips, crTips, advTips1]
            }
        ]
    });
    tmpPanel.show();



    formAllReset();

    formRefresh();


});