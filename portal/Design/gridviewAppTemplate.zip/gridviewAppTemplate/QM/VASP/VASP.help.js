var introTips = new Ext.Panel({
    autoScroll : true,
    width : 280,
    html: '<p><br/>VASP软件是材料研发领域应用最广泛的量子化学软件之一，是计算固体电子结构的首选程序，\
    在国内高校、科研院所等单位具有很大的用户群体。VASP软件提供源码(Fortran)，在编译安装过程中可根据需\
    要自由选择编译器、数学库和MPI并行库。</p><p>&nbsp;</p>',
    title: 'Introduction',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true, 
    collapsible: true, 
    collapsed: false
});



var runTips = new Ext.Panel({
    autoScroll : true,
    width : 280,
    html: '<p><br />MPI Type:<br /><br />选择MPI并行环境，如Open MPI或Intel MPI。</p> \
    <p><br />Remote Shell:<br /><br />多节点并行任务，MPI初始化并行环境时，节点之间的访问模式。建议采用默认的SSH模式。\
    </p><p><br />Commucation:<br /><br />多节点并行任务，节点之间数据交换采用何种网络。如果勾选“Share Memory”选项，\
    表示同一节点内的MPI进程采用共享内存方式进行数据交换；如果勾选“CPU Binding”选项，\
    表示将MPI进程与固定的CPU核心绑定，防止进程漂移。开启这两个选项通常可以提高MPI程序的运行速度。</p> \
    <p><br />MPI Program:<br /><br />选择本次计算任务的可执行程序。</p>\
    <p><br />Working DIR:<br /><br />本次计算任务的工作目录。</p> \
    <p><br />Output File:<br /><br />计算过程中的标准输出和标准错误输出信息，将被重定向保存为文件。</p><p>&nbsp;</p>',
    title: 'Run Tips',
    border: true,
    hideCollapseTool: false,
    titleCollapse: true, 
    collapsible: true, 
    collapsed: true
});
