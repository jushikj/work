﻿/*!
 * Ext JS Library 3.3.0
 * Copyright(c) 2006-2010 Ext JS, Inc.
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
/**
 * 从/opt/gridview/software/下载指定名称的软件
 *
 * @param {}
 *            softwareName
 */

  //Ext.QuickTips.init(); //ie下会有问题；

  var currentnode;
  var currentfile;

  var queue;
  var outputstring;

  var numnodes;
  var maxnodes;
  var numppn;
  var maxppn;
  var name;
  var hours;
  var maxhours;
  var minutes;
  var seconds;
  var mpitype;
  var mpilist;
  var workpath;
  var remoteshell;
  var output;
  var network;
  var isib;
  var program;
  var programarg;
  var checkpoint_available;
  var checkpoint_def;
  var interval_def;

  var tem;
  var mpi;
  var wpath;
  var showpath;
  var upPath;
  var pathsplit;
  var upfilePath;
  var filepathsplit;
  var UserHomePath;
  var homepath;
  var vnc_available;
  var maxNNodes;
  var tmpNNodes;
  var totQueNodes;
  var maxQueNodes;
  var maxQueCores;

  var gap_remote_sh = null;
  var gap_network = null;
  var gap_share_mem = null;
  var gap_cpu_binding = null;
  var gap_linda_para = null;
  var gap_vnc = null;
  var gap_checkpoint = null;
  var gap_interval = null;

  var tcp_mark = 1;
  var memory_mark = 1;
  var ib_mark = 1;
  var checkpoint_mark = 1;
  var interval_mark = 1;
  var pathUp_mark = 0;
  var fileUp_mark = 0;
  var queChargeRate = 1.0;

  var currDate = new Date();
  var timeStamp = currDate.format('md_His');

function coreSoftwareDownload(softwareName) {

  var softwareWebRoot = "/commonsoft/";
  var rePath = "";

  Ext.Ajax.request({
    url : softwareWebRoot + "softwaremanagement/softwareDownload.action",
    callback : function(options, success, response) {
      if (Ext.decode(response.responseText)['success'] == true)
      {
        var softwareUrl = Ext.decode(response.responseText)["path"];
        window.open(softwareWebRoot + softwareUrl);
        } else {
          Ext.MessageBox.show({
            title : gvI18n('错误'),
            msg : gvI18n("您要下载的软件不存在"),
            buttons : Ext.MessageBox.OK,
            icon : Ext.MessageBox.ERROR
            });
          }
      },
    params : {
        softwareName : softwareName
        },
    scope : this
    });

  return rePath;

}

/****************************WinSCP*******************************************/

/*
 * Gridview ParameterView 模块
 */

// Ext.namespace('gridview.core.pageintegration.webapp.commonsoftwaremanagement');
/**
 * 支持winscp、putty的启动
 *
 * @param softwareName,
 *            ipPath, initPath ipPath:访问IP地址 initPath：访问起始目录
 *            如："/opt/gridview/"
 * @return
 */
function coreSoftwareOpen(softwareName, ipPath, initPath) {

  // 1.获取用户信息
  var osUser = portal_strOsUser;
  var gvUser = portal_strGvUser;
  var userMode = portal_strUserMode;
  var userPasswd = portal_strUserPasswd;
  initPath = initPath + "/";

  // 2.操作系统判定,只支持Windows操作系统
  var isWin = (navigator.platform == "Win32") || (navigator.platform == "Windows");

  if (!isWin) {
    Ext.MessageBox.show( {
      title : gvI18n("winscp_error"),
      msg : gvI18n("winscp_ossupport"),
      buttons : Ext.MessageBox.OK,
      icon : Ext.MessageBox.ERROR
    });
    return;
  }

  try {
    // 3.获取登录节点IP
    var sip = ipPath;
    var cmd = "";
    var arg = "";
    // 4判断浏览器类型IE
    if (MzBrowser.ie) {
      // 4.1 用户类型判定
      if (userMode == 'systemUser') {
        // 4.1.1判断软件类型
        if (softwareName == "winscp") {
          cmd = "winscp.exe sftp://" + osUser + ":"
              + userPasswd + "@" + sip + initPath;
        } else if (softwareName == "putty") {
          cmd = "putty.exe " + osUser + "@" + sip + " -pw "
              + userPasswd;
        }
      } else {
        if (softwareName == "winscp") {
          cmd = "winscp.exe sftp://" + osUser + "@" + sip
              + initPath;
        } else if (softwareName == "putty") {
          cmd = "putty.exe " + osUser + "@" + sip;
        }
      }

      // 4.2 启动Winscp
      var tmpObj = new ActiveXObject("wscript.shell").run(cmd);
    }

    // 4判断浏览器类型FF
    if (MzBrowser.firefox) {
      // 软件判断
      var cmd64 = "";

      if (softwareName == "winscp") {
        cmd = "C:\\Program\ Files\\Sugon\ WinSCP&Putty\\WinSCP.exe";
        cmd64 = "C:\\Program\ Files\ (x86)\\Sugon\ WinSCP&Putty\\WinSCP.exe";
      } else if (softwareName == "putty") {
        cmd = "C:\\Program\ Files\\Sugon\ WinSCP&Putty\\putty.exe";
        cmd64 = "C:\\Program\ Files\ (x86)\\Sugon\ WinSCP&Putty\\putty.exe";
      }
      // 4.1 用户类型判定
      var arguments = [ arg ];

      if (userMode == 'systemUser') {
        // 软件判断
        if (softwareName == "winscp") {
          arg = "sftp://" + osUser + ":" + userPasswd + "@"
              + sip + initPath;
          arguments = [ arg ];

        } else if (softwareName == "putty") {
          var arg0 = osUser + "@" + sip;
          var arg1 = "-pw";
          var arg2 = userPasswd;
          arguments = [ arg0, arg1, arg2 ];
        }
      } else {
        // 软件判断
        if (softwareName == "winscp") {
          arg = "sftp://" + osUser + "@" + sip + initPath;
        } else if (softwareName == "putty") {
          arg = osUser + "@" + sip;
        }
        arguments = [ arg ];
      }

      // 4.2 启动Winscp
      netscape.security.PrivilegeManager
          .enablePrivilege("UniversalXPConnect");
      var process = Components.classes['@mozilla.org/process/util;1']
          .createInstance(Components.interfaces.nsIProcess);
      var file = Components.classes['@mozilla.org/file/local;1']
          .createInstance(Components.interfaces.nsILocalFile);
      try {
        file.initWithPath(cmd);
        process.init(file);
        process.run(false, arguments, arguments.length, {});
      } catch (e) {
        // 64位系统判定
        file.initWithPath(cmd64);
        process.init(file);
        process.run(false, arguments, arguments.length, {});
      }
    }
  } catch (e) {
    // 5 启动失败提示
    var linkcannotopen = "";
    if (softwareName == "winscp") {
      var linkcannotopen = gvI18n("无法启动WinSCP，请确定以下操作是否均已完成：");
    } else if (softwareName == "putty") {
      var linkcannotopen = gvI18n("putty_cannotopen");
    }
    var linkdownloadconf = gvI18n("请下载并安装WinSCP程序。")
        + "<a href=\"#\" onclick=\"coreSoftwareDownload('winscp_puttysetup.exe');\">"
        + gvI18n("点击下载WinSCP") + "</a>";
    if (MzBrowser.ie) {
      // ie设置提示
      var winscpieset = gvI18n("安全设置中“ActiveX空间和插件”的“对未标记为可安全执行的脚本的ActiveX控件初始化并执行脚本”项已改为“启用”");
      Ext.MessageBox.show( {
        title : gvI18n("提示"),
        msg : linkcannotopen + "<br/><br/>1." + winscpieset
            + "<br/><br/>2." + linkdownloadconf,
        buttons : Ext.MessageBox.OK,
        icon : Ext.MessageBox.INFO
      });
    }
    if (MzBrowser.firefox) {
      // ff设置提示
      var winscpffset = gvI18n("请在浏览器地址栏输入“about:config”并回车，将[signed.applets.codebase_principal_support]设置为true");
      Ext.MessageBox.show( {
        title : gvI18n("提示"),
        msg : linkcannotopen + "<br/><br/>1." + winscpffset
            + "<br/><br/>2." + linkdownloadconf,
        buttons : Ext.MessageBox.OK,
        icon : Ext.MessageBox.INFO
      });
    }
  }

}

/**
 * 浏览器判定使用
 *
 * @type
 */
window["MzBrowser"] = {};
(function() {
  if (MzBrowser.platform)
    return;
  var ua = window.navigator.userAgent;
  MzBrowser.platform = window.navigator.platform;

  MzBrowser.firefox = ua.indexOf("Firefox") > 0;
  MzBrowser.opera = typeof (window.opera) == "object";
  MzBrowser.ie = !MzBrowser.opera && ua.indexOf("MSIE") > 0;
  MzBrowser.mozilla = window.navigator.product == "Gecko";
  MzBrowser.netscape = window.navigator.vendor == "Netscape";
  MzBrowser.safari = ua.indexOf("Safari") > -1;

  if (MzBrowser.firefox)
    var re = /Firefox(\s|\/)(\d+(\.\d+)?)/;
  else if (MzBrowser.ie)
    var re = /MSIE( )(\d+(\.\d+)?)/;
  else if (MzBrowser.opera)
    var re = /Opera(\s|\/)(\d+(\.\d+)?)/;
  else if (MzBrowser.netscape)
    var re = /Netscape(\s|\/)(\d+(\.\d+)?)/;
  else if (MzBrowser.safari)
    var re = /Version(\/)(\d+(\.\d+)?)/;
  else if (MzBrowser.mozilla)
    var re = /rv(\:)(\d+(\.\d+)?)/;

  if ("undefined" != typeof (re) && re.test(ua))
    MzBrowser.version = parseFloat(RegExp.$2);
})();


/*** ********************************openPath函数*************************************/

            function openPath() {
              wpath = UserHomePath;

              if (document.getElementById("pathwin") == null) {
                window1.innerHTML = "";

                var id1 = '/';
                currentnode = '/';

                if (Ext.getCmp("path").getValue() != '') {
                  id1 = Ext.getCmp("path").getValue();
                  currentnode = Ext.getCmp("path").getValue();
                }

                if (currentnode == "HOME")
                  showpath = UserHomePath;
                else
                  showpath = currentnode;

                var pathtreeloader = new Ext.tree.TreeLoader(
                    {
                      url : "/jm_as/appsubmit/listUserDirectory.action"
                    });

                pathtreeloader.on('beforeload',function(ld, node) {
                  // 如果为work path的值为HOME
                  if (currentnode == "HOME")
                    currentnode = UserHomePath;
                  else if (pathUp_mark != 1)
                    currentnode = node.id;

                  pathUp_mark = 0;

                  ld.baseParams = {
                    strDirPath : currentnode,
                    strJobManagerID : portal_strJobManagerID,
                    strJobManagerAddr : portal_strJobManagerAddr,
                    strJobManagerPort : portal_strJobManagerPort,
                    strJobManagerType : portal_strJobManagerType
                    };
                  })

                var pathtree = new Ext.tree.TreePanel({
                  root : new Ext.tree.AsyncTreeNode({text : showpath,id : id1}),
                  autoScroll : true,
                  loader : pathtreeloader
                });

                new Ext.tree.TreeSorter(pathtree, {folderSort:true});

                var win = new Ext.Window(
                    {
                      renderTo : 'window1',
                      title : "选择路径",
                      id : "pathwin",
                      width : 200,
                      height : 375,
                      layout : 'fit',
                      closable : true,
                      draggable : true,
                      resizable : false,
                      buttons : [{
                        text : "确定",// iconCls:"browser",
                        width : 50,
                        handler : function() {
                          if (currentnode == "0" || leaf_node == true)
                            Ext.MessageBox.alert('提示','请选择路径',"");
                          else
                          {
                            Ext.getCmp("path").setValue(currentnode);
                            Ext.getCmp("inputFile").setValue( currentnode + "/test.gjf");
                            win.close();
                          }
                        }
                      },{
                        text : "关闭",// iconCls:"delete",
                        width : 50,
                        handler : function(){win.close()}
                      },{
                        text : "上级目录",
                        width : 50,// iconCls:"delete",
                        handler : function() {
                          pathsplit = currentnode.split("/");

                          upPath = "";
                          var num = 1;
                          while (pathsplit[num + 1] != null)
                            num++;
                          if (pathsplit[2] != null)
                          {
                            for (i = 1; i < num; i++)
                              upPath = upPath + '/' + pathsplit[i];
                          } else upPath = "/";

                          currentnode = upPath;
                          pathUp_mark = 1;
                          pathtree.root.reload();
                          pathtree.root.setText(upPath);
                        }
                      }],
                      items : pathtree
                    });

                var leaf_node = "0";
                win.setPosition(875, 340);
                win.show();

                pathtree.on("click", function(node) {
                  currentnode = node.id;
                  leaf_node = node.leaf;
                  });
                }

              }

/**************************openFile*******************************************/
            function openFile() {
              if (document.getElementById("filewin") == null)
              {
                window2.innerHTML = "";

                var id2 = '/';
                currentfile = '/';

                if (Ext.getCmp("file").getValue() != '')
                {
                  currentfile = Ext.getCmp("file").getValue();

                  filepathsplit = currentfile.split("/");
                  upfilePath = "";
                  var num = 1;
                  while (filepathsplit[num + 1] != null)
                    num++;

                  if (filepathsplit[2] != null)
                  {
                    for (i = 1; i < num; i++)
                      upfilePath = upfilePath+ '/' + filepathsplit[i];
                  } else
                    upfilePath = "/";

                  currentfile = upfilePath;
                  id2 = currentfile;
                }

                var filetreeloader = new Ext.tree.TreeLoader({
                  url : "/jm_as/appsubmit/listUserDirectory.action"
                    });

                filetreeloader.on('beforeload',function(ld, node) {
                  if (fileUp_mark == 0)
                    currentfile = node.id;

                  fileUp_mark = 0;

                  ld.baseParams = {
                      strDirPath : currentfile,
                      strJobManagerID : portal_strJobManagerID,
                      strJobManagerAddr : portal_strJobManagerAddr,
                      strJobManagerPort : portal_strJobManagerPort,
                      strJobManagerType : portal_strJobManagerType
                      };
                  })

                var filetree = new Ext.tree.TreePanel({
                  root : new Ext.tree.AsyncTreeNode( {text : currentfile,id : id2}),
                  autoScroll : true,
                  loader : filetreeloader
                  });

                new Ext.tree.TreeSorter(filetree, {folderSort:true});

                var win = new Ext.Window({
                  renderTo : 'window2',
                  title : "选择文件",
                  id : "filewin",
                  width : 200,
                  height : 375,
                  layout : 'fit',
                  closable : true,
                  draggable : true,
                  resizable : false,
                  buttons : [{
                    text : "确定",// iconCls:"browser",
                    width : 50,
                    handler : function() {
                      if (leaf_node1 == false)
                        Ext.MessageBox.alert('提示','请选择文件',"");
                      else
                      {
                        Ext.getCmp("file").setValue(currentfile);
                        //jobScriptRefresh();
                        win.close();
                      }
                    }
                  },{
                    text : "关闭",
                    width : 50,// iconCls:"delete",
                    handler : function() {win.close()}
                  },{
                    text : "上级目录",
                    width : 50,// iconCls:"delete",
                    handler : function() {
                      filepathsplit = currentfile.split("/");
                      upfilePath = "";
                      var num = 1;
                      while (filepathsplit[num + 1] != null)
                        num++;

                      if (filepathsplit[2] != null)
                      {
                        for (i = 1; i < num; i++)
                          upfilePath = upfilePath+ '/' + filepathsplit[i];
                      } else
                        upfilePath = "/";
                      currentfile = upfilePath;
                      fileUp_mark = 1;
                      filetree.root.reload();
                      filetree.root.setText(upfilePath);
                      }
                  }],
                  items : filetree
                });

                var leaf_node1 = "0";
                win.setPosition(875, 340);
                win.show();

                filetree.on("click", function(node) {
                  currentfile = node.id;
                  leaf_node1 = node.leaf;
                  });
                }
              }

/**************************openFileIn*******************************************/
            function openFileIn() {
              if (document.getElementById("filewin") == null)
              {
                window2.innerHTML = "";

                var id2 = '/';
                currentfile = '/';

                if (Ext.getCmp("inputFile").getValue() != '')
                {
                  currentfile = Ext.getCmp("inputFile").getValue();

                  filepathsplit = currentfile.split("/");
                  upfilePath = "";
                  var num = 1;
                  while (filepathsplit[num + 1] != null)
                    num++;

                  if (filepathsplit[2] != null)
                  {
                    for (i = 1; i < num; i++)
                      upfilePath = upfilePath+ '/' + filepathsplit[i];
                  } else
                    upfilePath = "/";

                  currentfile = upfilePath;
                  id2 = currentfile;
                }

                var filetreeloader = new Ext.tree.TreeLoader({
                  url : "/jm_as/appsubmit/listUserDirectory.action"
                    });

                filetreeloader.on('beforeload',function(ld, node) {
                  if (fileUp_mark == 0)
                    currentfile = node.id;

                  fileUp_mark = 0;

                  ld.baseParams = {
                      strDirPath : currentfile,
                      strJobManagerID : portal_strJobManagerID,
                      strJobManagerAddr : portal_strJobManagerAddr,
                      strJobManagerPort : portal_strJobManagerPort,
                      strJobManagerType : portal_strJobManagerType
                      };
                  })

                var filetree = new Ext.tree.TreePanel({
                  root : new Ext.tree.AsyncTreeNode( {text : currentfile,id : id2}),
                  autoScroll : true,
                  loader : filetreeloader
                  });

                new Ext.tree.TreeSorter(filetree, {folderSort:true});

                var win = new Ext.Window({
                  renderTo : 'window2',
                  title : "选择文件",
                  id : "filewin",
                  width : 200,
                  height : 375,
                  layout : 'fit',
                  closable : true,
                  draggable : true,
                  resizable : false,
                  buttons : [{
                    text : "确定",// iconCls:"browser",
                    width : 50,
                    handler : function() {
                      if (leaf_node1 == false)
                        Ext.MessageBox.alert('提示','请选择文件',"");
                      else
                      {
                        Ext.getCmp("inputFile").setValue(currentfile);
                        //jobScriptRefresh();
                        win.close();
                      }
                    }
                  },{
                    text : "关闭",
                    width : 50,// iconCls:"delete",
                    handler : function() {win.close()}
                  },{
                    text : "上级目录",
                    width : 50,// iconCls:"delete",
                    handler : function() {
                      filepathsplit = currentfile.split("/");
                      upfilePath = "";
                      var num = 1;
                      while (filepathsplit[num + 1] != null)
                        num++;

                      if (filepathsplit[2] != null)
                      {
                        for (i = 1; i < num; i++)
                          upfilePath = upfilePath+ '/' + filepathsplit[i];
                      } else
                        upfilePath = "/";
                      currentfile = upfilePath;
                      fileUp_mark = 1;
                      filetree.root.reload();
                      filetree.root.setText(upfilePath);
                      }
                  }],
                  items : filetree
                });

                var leaf_node1 = "0";
                win.setPosition(875, 340);
                win.show();

                filetree.on("click", function(node) {
                  currentfile = node.id;
                  leaf_node1 = node.leaf;
                  });
                }
              }
/** ********************* jobScriptRefresh ********************************************* */
/*
            function jobScriptRefresh() {
                 nCpus = Ext.getCmp("nnodes").getValue() * Ext.getCmp("ppn").getValue();

                 if ( Ext.getDom("ib").checked )
                    connNet = "openib";
                 else connNet = "tcp";

                 if ( Ext.getDom("memory").checked )
                    shareMem = ",sm";
                 else shareMem = "";

                 mcaBtl = " --mca btl self," + connNet + shareMem;

                 if ( Ext.getDom("ssh").checked )
                    rmSH = "-r ssh ";
                 else rmSH = "-r rsh ";

                 jobscriptstxt = "mpirun " + rmSH + "-np " + nCpus  + mcaBtl + " " + Ext.getCmp("file").getValue() + " " +Ext.getCmp("programarg").getValue();
                 Ext.getCmp("jobscripts").setValue(jobscriptstxt);
                 Ext.getCmp("jobscripts").disable();
              }


            function editJobScript() {
                 Ext.getCmp("jobscripts").enable();
            }
*/
            function cquotaBarRefresh() {
                 totCPUTime = queChargeRate * Ext.getCmp("nnodes").getValue() * Ext.getCmp("ppn").getValue() * Ext.getCmp("hours").getValue();
                 cqBarProgres =  totCPUTime / dUserCqHour;
                 if (cqBarProgres >1) cqBarProgres=1.0;
                 Ext.getCmp("cquotaBar").updateProgress(cqBarProgres);
            }
/*
            function mpiRelateRefresh() {
              if (Ext.getCmp("mpitype").getValue() != 'cr_mpi' && Ext.getCmp("mpitype").getValue() != 'mpich2')
              {
                if (isib == '1')
                {
                  Ext.getCmp("ib").enable();
                  Ext.getDom("ib").checked = true;
                  ib_mark = 1;
                  tcp_mark = 0;
                }
                else
                {
                  Ext.getCmp("ib").disable();
                  Ext.getDom("ib").checked = false;
                  ib_mark = 0;
                  Ext.getDom("tcp").checked = true;
                  tcp_mark = 1;
                }

                Ext.getCmp("checkpoint").disable();
                Ext.getDom("checkpoint").checked = false;
                checkpoint_mark = 0;
                Ext.getCmp("interval").disable();
                interval_mark = 0;
              }
              else if (Ext.getCmp("mpitype").getValue() == 'mpich2')
              {
                Ext.getCmp("ib").disable();
                Ext.getDom("ib").checked = false;
                ib_mark = 0;

                Ext.getDom("tcp").checked = true;
                tcp_mark = 1;

                Ext.getCmp("checkpoint").disable();
                Ext.getDom("checkpoint").checked = false;
                checkpoint_mark = 0;
                Ext.getCmp("interval").disable();
                interval_mark = 0;
              }
              else if (Ext.getCmp("mpitype").getValue() == 'cr_mpi')
              {
                if (isib == '1')
                {
                  Ext.getCmp("ib").enable();
                  Ext.getDom("ib").checked = true;
                  Ext.getDom("tcp").checked = false;
                  ib_mark = 1;
                  tcp_mark = 0;
                }
                else
                {
                  Ext.getCmp("ib").disable();
                  Ext.getDom("ib").checked = false;
                  ib_mark = 0;
                  Ext.getDom("tcp").checked = true;
                  tcp_mark = 1;
                }

                if (checkpoint_available == '1' )
                {
                  Ext.getCmp("check").enable();
                  checkpoint_mark = 1;
                  Ext.getCmp("interval").disable();
                  interval_mark = 0;
                }
                else
                {
                  Ext.getCmp("checkpoint").disable();
                  Ext.getDom("checkpoint").checked = false;
                  checkpoint_mark = 0;
                  Ext.getCmp("interval").disable();
                  interval_mark = 0;
                }
              }
            }
*/
            function formAllReset() {
               if (isib == '1')
               {
                 Ext.getDom("ib").checked = true;
               }
               else
               {
                 Ext.getDom("tcp").checked = true;
               }

                Ext.getCmp("nnodes").setMinValue('1');
                Ext.getCmp("nnodes").setMaxValue('1');
                Ext.getCmp("tcp").disable();
                Ext.getCmp("ib").disable();
                Ext.getCmp("rsh").disable();
                Ext.getCmp("ssh").disable();

               if (remoteshell == "rsh")
                 Ext.getDom("rsh").checked = true;

               if (vnc_available == '1' )
               { Ext.getCmp("IsVNC").enable(); }
               else
               { Ext.getCmp("IsVNC").disable(); }

               //if (checkpoint_available == 0 || checkpoint_def == 0|| mpitype != "cr_mpi")
               if (checkpoint_available == 0 || checkpoint_def == 0)
               {
                 Ext.getCmp("check").disable();
                 checkpoint_mark = 0;
                 Ext.getCmp("interval").disable();
                 interval_mark = 0;
               }
               else
               {
                 Ext.getCmp("check").enable();
                 checkpoint_mark = 1;
               }
               //console.log("numnodes=" + numnodes);
               Ext.getCmp("nnodes").setValue(numnodes);
               Ext.getCmp("ppn").setValue(numppn);
               
               Ext.getCmp("hours").setValue(hours);
               Ext.getCmp("minutes").setValue(minutes);
               Ext.getCmp("seconds").setValue(seconds);
               //Ext.getCmp("programarg").setValue(programarg_default);
               Ext.getCmp("path").setValue(UserHomePath);
               Ext.getCmp("inputFile").setValue(UserInputFile);
               Ext.getCmp("file").setValue(file);
               Ext.getCmp("interval").setValue(interval_def);
               
               currDate = new Date();
               timeStamp = currDate.format('md_His');
               Ext.getCmp("name").setValue(name + "_" + timeStamp);
               Ext.getCmp("output").setValue( output + "_" + timeStamp + '.txt' );
               
               //if (mpi_mpi_opt.length > 0)
               //Ext.getCmp("mpiAdvOpt").setValue(mpi_mpi_opt);
               
               if (mpi_pbs_opt.length > 0)
               {
                 mpi_pbs_opt=mpi_pbs_opt.replace(/:/ig,'\n');
                 Ext.getCmp("pbsAdvOpt").setValue(mpi_pbs_opt);
               }
               
               if (mpi_pre_cmd.length > 0)
               {
               	mpi_pre_cmd=mpi_pre_cmd.replace(/:/ig,'\n');
                 Ext.getCmp("preCommands").setValue(mpi_pre_cmd);
               }
               
               if (mpi_post_cmd.length > 0)
               {
               	mpi_post_cmd=mpi_post_cmd.replace(/:/ig,'\n');
                 Ext.getCmp("postCommands").setValue(mpi_post_cmd);
               }
            }

            function queueRelateRefresh() {
            	  for( j=0; j< aQueStat.length; j++)
                {
                	if (Ext.getCmp("queue").getValue() == aQueStat[j][1])
                	{
                	  Ext.getCmp("ppn").setMaxValue(aQueStat[j][8]);
                	  Ext.getCmp("ppn").setValue(aQueStat[j][8]);

                	  if (aQueStat[j][13] != 'unlimit') //min nodes allowed
                	  {
                	  	Ext.getCmp("nnodes").setMinValue(aQueStat[j][13]);
                	  }

                	  queChargeRate=aQueStat[j][6];     //queue charge rate

                	  totQueNodes=aQueStat[j][2];       //total nodes in queue
                	  maxNNodes=aQueStat[j][2];

                	  maxQueNodes=aQueStat[j][10];      //max nodes allowed
                	  if (aQueStat[j][10] != 'unlimit')
                	  {
                	  	tmpNNodes=aQueStat[j][10];
                	  	if (maxNNodes > tmpNNodes) maxNNodes=tmpNNodes;
                	  }

                	  maxQueCores=aQueStat[j][11];        //max cores allowed
                	  if (aQueStat[j][11] != 'unlimit')
                	  {
                	    tmpNNodes=aQueStat[j][11] / aQueStat[j][8];
                	    if (maxNNodes > tmpNNodes) maxNNodes=tmpNNodes;
                	  }

                	  Ext.getCmp("nnodes").setMaxValue(maxNNodes);
                	  if(Ext.getCmp("nnodes").getValue() > maxNNodes) Ext.getCmp("nnodes").setValue(maxNNodes);

                	  break;
                  }
                }

            }
