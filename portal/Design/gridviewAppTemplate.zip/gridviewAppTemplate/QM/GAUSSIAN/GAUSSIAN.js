﻿

Ext.onReady(function() {

  // turn on validation errors beside the field globally
    Ext.form.Field.prototype.msgTarget = 'under';

/** ******************WinSCP地址传递(通过读取浏览器地址)************************** */

    // coreSoftwareOpen("winscp", 集群管理节点ip, UserHomePath)
    // 传递ip参数为：
    // 1.portal_strJobManagerAddr 通过gridview传递
    // 2.currentAddr 通过读取浏览器地址
    var currentAddr;
    var AddrSplit;
    currentAddr = location.host;
    AddrSplit = currentAddr.split(":");
    currentAddr = AddrSplit[0];

/** *****************************提交表单****************************************** */
            mySubmit = function() {

              wpath = Ext.getCmp("path").getValue();

/** *****************************获取单选框参数值****************************************** */

              if (Ext.getCmp("rsh").getValue() == true)
                gap_remote_sh = 'rsh';
              else
                gap_remote_sh = 'ssh';

              if ((ib_mark == 1) && (Ext.getCmp("ib").getValue() == true))
                gap_network = 'ib';
              else if ((tcp_mark == 1) && (Ext.getCmp("tcp").getValue() == true))
                gap_network = 'tcp';
/*
              if ((memory_mark == 1) && (Ext.getCmp("memory").getValue() == true))
                gap_share_mem = '1';
              else
              	gap_share_mem = null;
*/
              if ((Ext.getCmp("lindaPara").getValue() == true))
                gap_linda_para = '1';
              else
                gap_linda_para = null;

              if ((Ext.getCmp("IsVNC").getValue() == true))
                gap_vnc = '1';
              else
              	gap_vnc = null;

              if (checkpoint_mark == 0)
                gap_checkpoint = null;
              else if (Ext.getCmp("checkpoint").getValue() == true)
                gap_checkpoint = '1';
              else
                gap_checkpoint = null;

              if (interval_mark == 0 || Ext.getCmp("checkpoint").getValue() == false)
                gap_interval = null;
              else
                gap_interval = Ext.getCmp("interval").getValue();

              gap_pbsAdvOpt=Ext.getCmp("pbsAdvOpt").getValue();
              gap_pbsAdvOpt=gap_pbsAdvOpt.replace(/\n/ig,'...');

              gap_preCMD=Ext.getCmp("preCommands").getValue();
              gap_preCMD=gap_preCMD.replace(/\n/ig,'...');
              //gap_preCMD_mod=gap_preCMD.replace(/\$/ig,'\$');

              gap_postCMD=Ext.getCmp("postCommands").getValue();
              gap_postCMD=gap_postCMD.replace(/\n/ig,'...');
              //gap_postCMD_mod=gap_postCMD.replace(/\$/ig,'\$');
/** ************************************************************************************ */

              if (!simple.getForm().isValid())
                Ext.MessageBox.alert('提醒', '对不起，您提交的信息有误！', "");
              else if (clusquota_available==1 && queChargeRate * Ext.getCmp("nnodes").getValue() * Ext.getCmp("ppn").getValue() * (Ext.getCmp("hours").getValue()*3600 + Ext.getCmp("minutes").getValue()*60 + Ext.getCmp("seconds").getValue()) > dUserCqSec)
              	Ext.MessageBox.alert('提醒', '对不起，您申请的机时资源超过配额，请减少Walltime的值！', "");
              else
                Ext.Ajax.request( {
                      url : "/jm_as/appsubmit/submitAppJob.action",
                      // method:"post",
                      scope : this,
                      // waitMsg:"查询中,请稍后！",
                      params : {
                        strJobManagerID : portal_strJobManagerID,
                        strJobManagerAddr : portal_strJobManagerAddr,
                        strJobManagerPort : portal_strJobManagerPort,
                        strJobManagerType : portal_strJobManagerType,
                        strAppType : portal_strAppType,
                        strAppName : portal_strAppName,
                        strOSUser : portal_strOsUser,
                        strKeyWord : "k1;k2;;;;",
                        strRemark : "remarktest",
                        mapAppJobInfo : Ext.util.JSON.encode( {
                              "GAP_GAUSS_NNODES"       : Ext.getCmp("nnodes").getValue(),
                              "GAP_GAUSS_PPN"          : Ext.getCmp("ppn").getValue(),
                              "GAP_GAUSS_WALL_TIME"    : Ext.getCmp("hours").getValue()+ ":" + Ext.getCmp("minutes").getValue()+ ":" + Ext.getCmp("seconds").getValue(),
                              "GAP_GAUSS_QUEUE"        : Ext.getCmp("queue").getValue(),
                              "GAP_GAUSS_NAME"         : Ext.getCmp("name").getValue(),

                            //"GAP_GAUSS_MPI_TYPE"     : Ext.getCmp("mpitype").getValue(),
                              "GAP_GAUSS_REMOTE_SHELL" : gap_remote_sh,
                              "GAP_GAUSS_COMMUCATION"  : gap_network,
                            //"GAP_GAUSS_SHARE_MEMORY" : gap_share_mem,
                            //"GAP_GAUSS_CPU_BINDING"  : gap_cpu_binding,
                              "GAP_GAUSS_LINDA_PARA"   : gap_linda_para,
                              "GAP_GAUSS_PROGRAM"      : Ext.getCmp("file").getValue(),
                            //"GAP_GAUSS_PROGRAM_ARG"  : Ext.getCmp("programarg").getValue(),
                              "GAP_GAUSS_WORK_DIR"     : wpath,
                              "GAP_GAUSS_INPUT"        : Ext.getCmp("inputFile").getValue(),
                              "GAP_GAUSS_OUTPUT"       : Ext.getCmp("output").getValue(),

                              "GAP_GAUSS_VNC"          : gap_vnc,

                              "GAP_GAUSS_CKECK_POINT"  : gap_checkpoint,
                              "GAP_GAUSS_INTERVAL"     : gap_interval,

                            //"GAP_GAUSS_MPI_OPT"      : "\'" + Ext.getCmp("mpiAdvOpt").getValue() + "\'",
                              "GAP_GAUSS_PBS_OPT"      : "\'" + gap_pbsAdvOpt + "\'",
                              "GAP_GAUSS_PRE_CMD"      : "\'" + gap_preCMD + "\'",
                              "GAP_GAUSS_POST_CMD"     : "\'" + gap_postCMD + "\'"
                              })
                            },

                      success : function(response,options) {
                        try {
                          var result = Ext.util.JSON.decode(response.responseText);

                          if (result.exitVal == 0)
                          {
                            var resultStr = "Job submitted successfully！<br/><br/>Job ID："+ result.stdOut;

                            Ext.MessageBox.show({
                              title : "Success",
                              msg : resultStr,
                              buttons : Ext.MessageBox.OK,
                              icon : Ext.MessageBox.INFO
                              });

                            currDate = new Date();
                            timeStamp = currDate.format('md_His');
                            Ext.getCmp("name").setValue(name + "_" + timeStamp);
                            Ext.getCmp("output").setValue( output +"_" +  timeStamp + '.txt' );
                          }
                          else
                          {
                            var resultStr = "Job submitting failed！<br/><br/>"+ result.stdOut + "<br/><br/>"+ result.stdErr;
                            Ext.MessageBox.show({
                              title : "Error",
                              msg : resultStr,
                              buttons : Ext.MessageBox.OK,
                              icon : Ext.MessageBox.ERROR
                              });
                            }
                          }
                        catch (e) {}
                        },

                      failure : function(response,options){
                          var resultStr = "Job submitting failed!";
                          Ext.MessageBox.show({
                            title : "Error",
                            msg : resultStr,
                            buttons : Ext.MessageBox.OK,
                            icon : Ext.MessageBox.ERROR
                            });
                          }
                      });
              }

/** ******************************表单初始化****************************************** */

            var s_QueStat=new Ext.data.SimpleStore({data:aQueStat,fields:["id","QueName","TotNodes","BusyNodes","FreeNodes","FreeCores", "ChargeRate", "IsQueAcce","MaxPPN","MaxMem","MaxNodes","MaxCores","MaxWalltime","MinNodes","MinCores","MinWalltime"]});

            var s_QueList=new Ext.data.SimpleStore({data:aQueList,fields:["QUEUE"]});

            var strUserCqHour;
            if (clusquota_available == 1) strUserCqHour = dUserCqHour + " CPU*Hours";
            else strUserCqHour = "unlimit";

            var strDiskQuota;
            var fDiskQuota;
            if (diskquota_available == 1)
            {
            	strDiskQuota = diskfilesystem + "   " + disklimitsgb + "GB";
            	fDiskQuota = diskused / disklimits;
            }
            else
            {
            	strDiskQuota = "unlimit";
            	fDiskQuota = 0.0;
            }

            var simple = new Ext.FormPanel(
                {
                  labelAlign : 'left',
                  frame : true,
                  title : portal_strAppName + " Portal v" + portal_version,
                  layout : "form",
                  bodyStyle : 'padding:5px 5px 0',
                  width : 800,
                  buttonAlign : "center",
                  items : [{
                        xtype : 'panel',
                        border : false,
                        html : '<p align="center"><img src="' + imgName + '"/></p>'
                      },
                      { title: 'Available Resource',
                        xtype: 'fieldset',
                        id: 'ResourceSet',
                        anchor: '100%',
                        items: [
                            {
                                xtype: 'grid',
                                id: 'QueStatGrid',
                                height: 160,
                                hideCollapseTool: false,
                                titleCollapse: true,
                                collapsible: true,
                                collapsed: false,
                                width : 745,
                                title: 'Queue Status',
                                store: s_QueStat,
                                columns: [
                                    {
                                        xtype: 'gridcolumn',
                                        dataIndex: 'QueName',
                                        editable: false,
                                        header: 'Queue Name',
                                        sortable: true,
                                        width: 120
                                    },
                                    {
                                        xtype: 'numbercolumn',
                                        align: 'right',
                                        dataIndex: 'TotNodes',
                                        editable: false,
                                        header: 'Total Nodes',
                                        sortable: true,
                                        width: 85,
                                        format: '000000'
                                    },
                                    {
                                        xtype: 'numbercolumn',
                                        align: 'right',
                                        dataIndex: 'BusyNodes',
                                        editable: false,
                                        header: 'Busy Nodes',
                                        sortable: true,
                                        width: 85,
                                        format: '000000'
                                    },
                                    {
                                        xtype: 'numbercolumn',
                                        align: 'right',
                                        dataIndex: 'FreeNodes',
                                        editable: false,
                                        header: 'Free Nodes',
                                        sortable: true,
                                        width: 85,
                                        format: '000000'
                                    },
                                    {
                                        xtype: 'numbercolumn',
                                        align: 'right',
                                        dataIndex: 'FreeCores',
                                        header: 'Free Cores',
                                        sortable: true,
                                        width: 90,
                                        format: '000000'
                                    },
                                    {
                                        xtype: 'numbercolumn',
                                        align: 'right',
                                        dataIndex: 'ChargeRate',
                                        header: 'Charge Rate',
                                        sortable: true,
                                        width: 85
                                    },
                                    {
                                        xtype: 'booleancolumn',
                                        align: 'right',
                                        dataIndex: 'IsQueAcce',
                                        editable: false,
                                        header: 'Accessible',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MaxPPN',
                                        header: 'Max PPN',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MaxMem',
                                        header: 'Max Memory',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MaxNodes',
                                        header: 'Max Nodes',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MaxCores',
                                        header: 'Max Cores',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MaxWalltime',
                                        header: 'Max Walltime',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MinNodes',
                                        header: 'Min Nodes',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MinCores',
                                        header: 'Min Cores',
                                        sortable: true,
                                        width: 80
                                    },
                                    {
                                        xtype: 'gridcolumn',
                                        align: 'right',
                                        dataIndex: 'MinWalltime',
                                        header: 'Min Walltime',
                                        sortable: true,
                                        width: 80
                                    }
                                ]
                            },
                            {
                                xtype: 'spacer',
                                height: 12
                            },
                            {
                                xtype: 'label',
                                text: 'ClusQuota Disk Usage :'
                            },
                            {
                                xtype: 'progress',
                                name: 'dskQuotaBar',
                                id: 'dskQuotaBar',
                                width: 745,
                                text:  strDiskQuota,
                                value: fDiskQuota
                            },
                            {
                                xtype: 'spacer',
                                height: 12
                            },
                            {
                                xtype: 'label',
                                text: 'ClusQuota CPU Time :'
                            },
                            {
                                xtype: 'progress',
                                name: 'cquotaBar',
                                id: 'cquotaBar',
                                width: 745,
                                animate: true,
                                text:  strUserCqHour,
                                value: 0.0
                            }
                        ]
                      },
                      { title : "Job Schedule Parameters",
/*********************Job Schedule Parameter*************************************/
                        layout : "column",
                        xtype : 'fieldset',
                        hideCollapseTool: false,
                        titleCollapse: true,
                        collapsible: true,
                        autoWidth : true,
                        items : [
                            { layout : "form",
                              columnWidth : .5,
                              labelWidth : 80,
                              items : [
                                  {fieldLabel : 'Nnodes',
                                    xtype : 'numberfield',
                                    labelWidth : 80,
                                    name : 'nnodes',
                                    id : "nnodes",
                                    //maxValue : maxnodes,
                                    allowBlank : false,
                                    allowNegative : false,
                                    allowDecimals : false
                                  },
                                  {fieldLabel : 'Cores/Node',
                                    labelWidth : 80,
                                    xtype : 'numberfield',
                                    name : 'ppn',
                                    id : "ppn",
                                    maxValue : maxppn,
                                    allowBlank : false,
                                    allowNegative : false,
                                    allowDecimals : false
                                  },
                                  {layout : "column",
                                    fieldLabel : 'Wall Time',
                                    items : [{
                                          name : 'hours',
                                          id : "hours",
                                          xtype : 'numberfield',
                                          width : 45,
                                          maxValue : maxhours,
                                          allowNegative : false,
                                          allowDecimals : false,
                                          allowBlank : false
                                        },
                                        {
                                          xtype : 'displayfield',
                                          value : 'hh'
                                        },
                                        {
                                          name : 'minutes',
                                          id : "minutes",
                                          xtype : 'numberfield',
                                          width : 24,
                                          maxValue : 59,
                                          allowNegative : false,
                                          allowDecimals : false,
                                          allowBlank : false
                                        },
                                        {
                                          xtype : 'displayfield',
                                          value : 'mm'
                                        },
                                        {
                                          name : 'seconds',
                                          id : "seconds",
                                          xtype : 'numberfield',
                                          width : 24,
                                          maxValue : 59,
                                          allowNegative : false,
                                          allowDecimals : false,
                                          allowBlank : false
                                        },
                                        {
                                          xtype : 'displayfield',
                                          value : 'ss'
                                        }
                                      ]
                                  }

                                ]
                            },
                            { layout : "form",
                              columnWidth : .5,
                              labelWidth : 54,
                              items : [
                                  {fieldLabel : 'Queue',
                                    width : 200,
                                    xtype : 'combo',
                                    mode : 'local',
                                    id : 'queue',
                                    value : queSelected,
                                    triggerAction : 'all',
                                    forceSelection : true,
                                    editable : false,
                                    name : 'queue',
                                    valueField : 'QUEUE',
                                    displayField : 'QUEUE',
                                    store : s_QueList
                                  },
                                  {fieldLabel : 'Name',
                                    width : 200,
                                    xtype : 'textfield',
                                    name : 'name',
                                    id : "name",
                                    allowBlank : false
                                  },
                                  {
                                    xtype : 'button',
                                    text : 'Manage Job File',
                                    id : 'winscp',// iconCls:"plusAnimation",
                                    handler : function() {
                                    coreSoftwareOpen("winscp",currentAddr,UserHomePath);
                                    }
                                  }
                                ]
                            }
                        ]
                      },
                      { title : "Run Parameters",
/*******************************Run Parameter*************************************/
                        layout : "form",
                        xtype : 'fieldset',
                        autoWidth : true,
                        hideCollapseTool: false,
                        titleCollapse: true,
                        collapsible: true,
                        labelWidth : 80,
                        items : [
                          { layout : 'column',
                              items : [
                                  { layout : 'form',
                                    columnWidth : .6,
                                    items : [
                                    { fieldLabel : 'Gaussian Bin',
                                      xtype : 'combo',
                                      width : 340,
                                      mode : 'local',
                                      id : 'file',
                                      value : file,
                                      triggerAction : 'all',
                                      forceSelection : true,
                                      editable : false,
                                      name : 'file',
                                      displayField : 'GAUSSPROG',
                                      valueField : 'GAUSSPROG',
                                      store : s_gaussProg
                                    }]
                                  },
                                  { xtype : 'button',
                                    columnWidth : .1,
                                    text : "Browse...",
                                    handler : openFile
                                  }
                                ]
                          },
/*
                          { layout : "column",
                            width : 450,
                            autoWidth : true,
                            items : [
                                  { layout : "form",
                                    columnWidth : .5,
                                    labelWidth : 80,
                                    items : [
                                        {  fieldLabel : 'MPI Type',
                                           id : 'mpitype',
                                          xtype : 'combo',
                                          mode : 'local',
                                          width : 180,
                                          value : mpitype,
                                          triggerAction : 'all',
                                          forceSelection : true,
                                          editable : false,
                                          name : 'mpitype',
                                          displayField : 'MPI',
                                          valueField : 'MPI',
                                          store : s_mpi
                                        }
                                      ]
                                  },
                                  {   xtype: 'checkbox',
                                  columnWidth : .15,
                                  id: 'memory',
                                  name: 'shareMem',
                                  boxLabel: 'Share Memory',
                                  inputValue : 'memory',
                                  checked: true
                                  }
                                ]
                          },
*/
                          { layout : 'column',
                            items : [
                              {layout : 'form',
                               columnWidth : .25,
                               items : [{ xtype: 'checkboxgroup',
                                          fieldLabel: 'Linda Parallel',
                                          //id: 'mpiSmBind',
                                          //name: 'mpiSmBind',
                                          items: [
                                            {
                                              xtype: 'checkbox',
                                              id: 'lindaPara',
                                              name: 'lindaPara',
                                              boxLabel: 'Yes',
                                              inputValue : 'lindaPara',
                                              checked: false
                                            }
                                          ]
                                        }
                                       ]
                              },
                              { layout : 'form',
                                columnWidth : .4,
                                items : [
                                 {  fieldLabel : 'Commucation',
                                    xtype : 'radiogroup',
                                    id: 'commRadio',
                                    name: 'commRadio',
                                     width : 145,
                                     items : [{
                                           boxLabel : 'TCP',
                                           name : 'network',
                                           id : 'tcp',
                                           inputValue : 'tcp'
                                         },
                                         {
                                           boxLabel : 'Infiniband',
                                           name : 'network',
                                           id : 'ib',
                                           inputValue : 'ib',
                                           checked : true
                                         }
                                       ]
                                  }
                                 ]
                              },
                              { layout : "form",
                                columnWidth : .3,
                                items : [
                                    { fieldLabel : 'Remote Shell',
                                    	id: 'rshRadio',
                                    	name: 'rshRadio',
                                      xtype : 'radiogroup',
                                      items : [
                                          { boxLabel : 'RSH',
                                            name : 'sh',
                                            id : 'rsh',
                                            inputValue : 'RSH'
                                          },
                                          { boxLabel : 'SSH',
                                            name : 'sh',
                                            id : 'ssh',
                                            inputValue : 'SSH',
                                            checked : true
                                          }
                                        ]
                                    }
                                  ]
                              }
                            ]
                          },
/*
                          { fieldLabel : 'Arguments',
                              width : 340,
                              xtype : 'textfield',
                              name : 'programarg',
                              id : "programarg",
                              allowBlank : false
                          },
*/
                          { layout : 'column',
                            items : [
                               {  layout : 'form',
                                  columnWidth : .6,
                                  items : [{
                                    fieldLabel : 'Working DIR',
                                    width : 340,
                                    xtype : 'textfield',
                                    name : 'path',
                                    id : "path",
                                    allowBlank : false
                                  }]
                                },
                                { columnWidth : .1,
                                  xtype : 'button',
                                  text : "Browse...",
                                  id : "PathBtn",
                                  handler:openPath
                                }
                              ]
                          },
                          { layout : 'column',
                              items : [
                                  { layout : 'form',
                                    columnWidth : .6,
                                    items : [
                                    { fieldLabel : 'Input File',
                                      xtype : 'textfield',
                                      width : 340,
                                      name : 'inputFile',
                                      id : "inputFile",
                                      value : 'test.gjf',
                                      allowBlank : false
                                    }]
                                  },
                                  { xtype : 'button',
                                    columnWidth : .1,
                                    text : "Browse...",
                                    handler : openFileIn
                                  }
                                ]
                          },
                          { fieldLabel : 'Output File',
                            xtype : 'textfield',
                            width : 340,
                            name : 'output',
                            id : "output",
                            allowBlank : false
                          }
                        ]
                      },
                      { title: 'Remote Visualization Parameters',
                          xtype: 'fieldset',
                          hideCollapseTool: false,
                          titleCollapse: true,
                          collapsible: true,
                          collapsed: true,
                          layout: 'column',
                          items: [
                              {   value: 'VNC Connection:',
                                  xtype: 'displayfield',
                                  anchor: '100%',
                                  fieldLabel: 'VNC Connection',
                                  columnWidth: 0.2
                              },
                              {
                                  xtype: 'checkbox',
                                  id: 'IsVNC',
                                  name: 'IsVNC',
                                  boxLabel: 'Yes',
                                  columnWidth: 0.3
                              }
/*,
                              {
                                  xtype: 'displayfield',
                                  value: 'VNC Server:',
                                  columnWidth: 0.15
                              },
                              {
                                  xtype: 'textfield',
                                  id: 'vncServer',
                                  name: 'vncServer',
                                  value: '60.28.43.216',
                                  disabled: true
                              }
*/
                          ]
                      },
                      { title : "Checkpoint/Restart Parameters",
/*** ****************************CheckPoint Parameter*************************************/
                        layout : "column",
                        xtype : 'fieldset',
                        hideCollapseTool: false,
                        titleCollapse: true,
                        collapsible: true,
                        collapsed: true,
                        autoWidth : true,
                        items : [
                        { layout : 'form',
                          columnWidth : .3,
                          items : [
                                   { xtype: 'checkboxgroup',
                                      labelWidth : 80,
                                     fieldLabel: 'Checkpoint',
                                     id: 'check',
                                     name: 'check',
                                     items: [
                                       { xtype: 'checkbox',
                                         id: 'checkpoint',
                                         name: 'checkpoint',
                                         boxLabel: 'Yes',
                                         inputValue : 'Yes',
                                         checked: false
                                       }
                                     ]
                                   }
                                 ]
                        },
                        {
                          layout : "form",
                          columnWidth : .4,
                          items : [{
                            fieldLabel : 'Internal',
                            layout : 'column',
                            items : [
                                {
                                  name : 'interval',
                                  xtype : 'numberfield',
                                  id : 'interval',
                                  width : 50,
                                  maxValue : 4320,
                                  allowNegative : false,
                                  allowDecimals : false,
                                  allowBlank : false
                                },
                                {
                                  xtype : 'displayfield',
                                  value : 'minutes'
                                }]
                           }]
                        }
                       ]
                      },
                      { title: 'Advanced Parameters',
                          xtype: 'fieldset',
                          id : 'advParamField',
                          name : 'advParamField',
                          autoHeight: true,
                          hideCollapseTool: false,
                          titleCollapse: true,
                          collapsible: true,
                          collapsed: true,
                          items: [
/*
                              {
                                  xtype : 'textfield',
                                  id: 'mpiAdvOpt',
                                  name: 'mpiAdvOpt',
                                  anchor: '100%',
                                  fieldLabel: 'MPI Options'
                              },
*/
                              {
                                  xtype: 'textarea',
                                  id: 'pbsAdvOpt',
                                  //autoHeight: true,
                                  height: 60,
                                  name: 'pbsAdvOpt',
                                  anchor: '100%',
                                  fieldLabel: 'PBS Options'
                              },
                              {
                                  xtype: 'textarea',
                                  id: 'preCommands',
                                  //autoHeight: true,
                                  height: 60,
                                  name: 'preCommands',
                                  anchor: '100%',
                                  fieldLabel: 'Pre Commands'
                              },
                              {
                                  xtype: 'textarea',
                                  id: 'postCommands',
                                  //autoHeight: true,
                                  height: 60,
                                  name: 'postCommands',
                                  anchor: '100%',
                                  fieldLabel: 'Post Commands'
                              }
                          ]
                      }
/*,
                      { title : "Executive Preview",
                        layout : "column",
                        xtype : 'fieldset',
                        autoWidth : true,
                        items : [{
                          labelWidth : 35,
                          width : 680,
                          fieldLabel : 'Job script',
                          xtype : 'textfield',
                          name : 'jobscripts',
                          id : "jobscripts",
                          allowBlank : false
                        },
                        {
                          xtype : 'button',
                          text : "Edit",
                          handler : editJobScript
                        }
                        ]
                      }
*/
                  ],

                  buttons : [
                      { text : 'Submit',
                      	id : 'submit',
                        handler : mySubmit
                      },
                      { text : 'Reset',
                        id : 'resetting',
                        // iconCls:'freshbutton',
                        handler : function()
                        {
                          simple.getForm().reset();
                          formAllReset();
                          //mpiRelateRefresh();
                          queueRelateRefresh();
                          if (clusquota_available == 1) cquotaBarRefresh();
                        }
                      }]
                });


            var tmpPanel = new Ext.Panel({
              renderTo:Ext.getBody(),
              autoScroll : true,
              layout : "column",
              width:1150,
              bodyStyle : 'padding-left:15px;padding-bottom:30px',
              frame:true,
              items:[{
                      layout : "form",
                      columnWidth : .73,
                      items:[simple]
                     },
                     {
                      layout : "form",
                      items:[introTips,resTips,jobTips,runTips,vncTips,crTips,advTips]
                     }
              ]
            });
            tmpPanel.show();
            formAllReset();
            //mpiRelateRefresh();
            queueRelateRefresh();
            if (clusquota_available == 1) cquotaBarRefresh();
            
            Ext.getCmp("path").on("change", function() {
              Ext.getCmp("inputFile").setValue( Ext.getCmp("path").getValue() + "/test.gjf");
            });

            Ext.getCmp("nnodes").on("change", function() {
              //jobScriptRefresh();
              if (clusquota_available == 1) cquotaBarRefresh();
            });

            Ext.getCmp("ppn").on("change", function() {
              //jobScriptRefresh();

              maxNNodes=totQueNodes;        //total nodes in queue, value defined by last queueRelateRefresh()

              if (maxQueNodes != 'unlimit') //max nodes allowed
              {
              	if (maxNNodes > maxQueNodes) maxNNodes=maxQueNodes;
              }

              if (maxQueCores != 'unlimit') //max cores allowed
              {
                tmpNNodes=maxQueCores / Ext.getCmp("ppn").getValue();
                if (maxNNodes > tmpNNodes) maxNNodes=tmpNNodes;
              }

              Ext.getCmp("nnodes").setMaxValue(maxNNodes);

              if (clusquota_available == 1) cquotaBarRefresh();
            });

            Ext.getCmp("hours").on("change", function() {
              if (clusquota_available == 1) cquotaBarRefresh();
            });
/*
            Ext.getCmp("programarg").on("change", function() {
              //jobScriptRefresh();
            });

            Ext.getCmp("tcp").on('check', function() {
              //jobScriptRefresh();
            });

            Ext.getCmp("ib").on('check', function() {
              //jobScriptRefresh();
            });

            Ext.getCmp("memory").on('check', function() {
              //jobScriptRefresh();
            });

            Ext.getCmp("rsh").on('check', function() {
              //jobScriptRefresh();
            });

            Ext.getCmp("ssh").on('check', function() {
              //jobScriptRefresh();
            });

            Ext.getCmp("file").on('select', function(comboBox) {
              //jobScriptRefresh();
            });
*/

            Ext.getCmp("lindaPara").on('check', function() {
              if (Ext.getCmp("lindaPara").getValue() == false)
              {
                Ext.getCmp("nnodes").setMinValue('1');
                Ext.getCmp("nnodes").setMaxValue('1');
                Ext.getCmp("tcp").disable();
                Ext.getCmp("ib").disable();
                Ext.getCmp("rsh").disable();
                Ext.getCmp("ssh").disable();
              }
              else
              {
                Ext.getCmp("nnodes").setMinValue('2');
                Ext.getCmp("nnodes").setMaxValue(maxNNodes);
                Ext.getCmp("tcp").enable();
                Ext.getCmp("ib").enable();
                Ext.getCmp("rsh").enable();
                Ext.getCmp("ssh").enable();
              }
            });
/*
            Ext.getCmp("mpitype").on('select', function() {
              mpiRelateRefresh();
            });
*/
            Ext.getCmp("queue").on('select', function() {
              queueRelateRefresh();
              if (clusquota_available == 1) cquotaBarRefresh();
            });

  });
